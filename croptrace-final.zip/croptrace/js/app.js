/* CropTrace UI - compiled to plain browser JS (no modules, no build step needed). */
(function(){
"use strict";
var exports={};
var React=window.React;
exports.Icon = Icon;
exports.Logo = Logo;
exports.Button = Button;
exports.Badge = Badge;
exports.SectionHeading = SectionHeading;
exports.Card = Card;
exports.DashboardTable = DashboardTable;
exports.BuyerSummary = BuyerSummary;
exports.CreateBatchModal = CreateBatchModal;
exports.BuyerModal = BuyerModal;
exports.AddEventModal = AddEventModal;
exports.WorkspaceHeading = WorkspaceHeading;
exports.default = Root;
window.CropTraceUI = { Icon: Icon, Logo: Logo, Button: Button, Badge: Badge, Card: Card, WorkspaceHeading: WorkspaceHeading };
const { useEffect, useState, useMemo } = React;
const api = window.CropTraceAPI;
function Icon({ name, size = 20 }) {
    const paths = {
        leaf: React.createElement(React.Fragment, null,
            React.createElement("path", { d: "M17.8 2.7C10.6 2.6 5 5.8 3.8 11.3c-.7 3.2 1 5.3 3.8 5.4 5.7.2 9-5.3 10.2-14Z" }),
            React.createElement("path", { d: "M3 19c2.4-4.4 5.8-7.8 10.7-10.6" })),
        arrow: React.createElement(React.Fragment, null,
            React.createElement("path", { d: "M4 10h12M12 6l4 4-4 4" })),
        batch: React.createElement(React.Fragment, null,
            React.createElement("path", { d: "m3 6 7-3 7 3-7 3-7-3Z" }),
            React.createElement("path", { d: "m3 10 7 3 7-3M3 14l7 3 7-3" })),
        cloud: React.createElement(React.Fragment, null,
            React.createElement("path", { d: "M5.5 15.5h9a3 3 0 0 0 .2-6 5 5 0 0 0-9.5-1.3 3.7 3.7 0 0 0 .3 7.3Z" }),
            React.createElement("path", { d: "m7 18 1-1m3 1 1-1" })),
        risk: React.createElement(React.Fragment, null,
            React.createElement("circle", { cx: "10", cy: "10", r: "7" }),
            React.createElement("path", { d: "M10 6v4l2.5 2M10 3v2M17 10h-2" })),
        scan: React.createElement(React.Fragment, null,
            React.createElement("path", { d: "M7 3H3v4M13 3h4v4M7 17H3v-4M13 17h4v-4" }),
            React.createElement("rect", { x: "7", y: "7", width: "6", height: "6", rx: "1" })),
        clock: React.createElement(React.Fragment, null,
            React.createElement("circle", { cx: "10", cy: "10", r: "7" }),
            React.createElement("path", { d: "M10 6v4l3 2" })),
        temperature: React.createElement(React.Fragment, null,
            React.createElement("path", { d: "M8 12.5V5a2 2 0 1 1 4 0v7.5a3.5 3.5 0 1 1-4 0Z" }),
            React.createElement("path", { d: "M10 9v5" })),
        route: React.createElement(React.Fragment, null,
            React.createElement("circle", { cx: "5", cy: "5", r: "2" }),
            React.createElement("circle", { cx: "15", cy: "15", r: "2" }),
            React.createElement("path", { d: "M7 5h3a3 3 0 0 1 3 3v0a3 3 0 0 1-3 3H8a3 3 0 0 0-3 3v0" })),
        shield: React.createElement(React.Fragment, null,
            React.createElement("path", { d: "M10 2.5 17 5v5c0 4.2-2.8 6.6-7 8-4.2-1.4-7-3.8-7-8V5l7-2.5Z" }),
            React.createElement("path", { d: "m7 10 2 2 4-4" })),
        phone: React.createElement(React.Fragment, null,
            React.createElement("rect", { x: "6", y: "2.5", width: "8", height: "15", rx: "2" }),
            React.createElement("path", { d: "M9 5h2M9 15h2" })),
        crop: React.createElement(React.Fragment, null,
            React.createElement("path", { d: "M10 18V7M10 11c-4 0-6-2-6-5 4 0 6 2 6 5ZM10 15c4 0 6-2 6-5-4 0-6 2-6 5Z" })),
        signal: React.createElement(React.Fragment, null,
            React.createElement("path", { d: "M3 15v2M7 12v5M11 9v8M15 5v12" })),
        database: React.createElement(React.Fragment, null,
            React.createElement("ellipse", { cx: "10", cy: "5", rx: "6", ry: "3" }),
            React.createElement("path", { d: "M4 5v5c0 1.7 2.7 3 6 3s6-1.3 6-3V5M4 10v5c0 1.7 2.7 3 6 3s6-1.3 6-3v-5" })),
        weather: React.createElement(React.Fragment, null,
            React.createElement("circle", { cx: "7", cy: "7", r: "3" }),
            React.createElement("path", { d: "M7 1v2M1 7h2M11 3l1-1M3 3 2 2M8 16h7a2.5 2.5 0 0 0 0-5 4 4 0 0 0-7.5 1.3A2 2 0 0 0 8 16Z" })),
        sensor: React.createElement(React.Fragment, null,
            React.createElement("circle", { cx: "10", cy: "10", r: "2" }),
            React.createElement("path", { d: "M6.5 6.5a5 5 0 0 0 0 7M13.5 6.5a5 5 0 0 1 0 7M3.5 3.5a9 9 0 0 0 0 13M16.5 3.5a9 9 0 0 1 0 13" })),
        code: React.createElement(React.Fragment, null,
            React.createElement("path", { d: "m7 5-5 5 5 5M13 5l5 5-5 5M11 3 9 17" })),
        menu: React.createElement(React.Fragment, null,
            React.createElement("path", { d: "M3 5h14M3 10h14M3 15h14" })),
        close: React.createElement(React.Fragment, null,
            React.createElement("path", { d: "m4 4 12 12M16 4 4 16" })),
        search: React.createElement(React.Fragment, null,
            React.createElement("circle", { cx: "9", cy: "9", r: "5.5" }),
            React.createElement("path", { d: "m13 13 4 4" })),
        bell: React.createElement(React.Fragment, null,
            React.createElement("path", { d: "M5 8a5 5 0 0 1 10 0v4l2 2H3l2-2V8ZM8 17h4" })),
        user: React.createElement(React.Fragment, null,
            React.createElement("circle", { cx: "10", cy: "7", r: "3" }),
            React.createElement("path", { d: "M4 17c.5-3.3 2.5-5 6-5s5.5 1.7 6 5" })),
        settings: React.createElement(React.Fragment, null,
            React.createElement("circle", { cx: "10", cy: "10", r: "2.5" }),
            React.createElement("path", { d: "M10 2v2M10 16v2M2 10h2M16 10h2M4.3 4.3l1.4 1.4M14.3 14.3l1.4 1.4M15.7 4.3l-1.4 1.4M5.7 14.3l-1.4 1.4" })),
        check: React.createElement("path", { d: "m4 10 4 4 8-9" }),
        refresh: React.createElement("path", { d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8M21 3v5h-5M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16M3 21v-5h5" }),
        sparkles: React.createElement("path", { d: "m10 2 1.5 4.5L16 8l-4.5 1.5L10 14l-1.5-4.5L4 8l4.5-1.5L10 2ZM15 13l1 2 2 1-2 1-1 2-1-2-2-1 2-1 1-2Z" }),
    };
    return (React.createElement("svg", { width: size, height: size, viewBox: "0 0 20 20", fill: "none", stroke: "currentColor", strokeWidth: "1.45", strokeLinecap: "round", strokeLinejoin: "round", "aria-hidden": "true" }, paths[name] || paths.leaf));
}
function Logo() {
    return (React.createElement("a", { className: "logo", href: "#/", "aria-label": "CropTrace home" },
        React.createElement("span", { className: "logo-mark" },
            React.createElement(Icon, { name: "leaf", size: 19 })),
        React.createElement("span", null, "CROPTRACE")));
}
function Button({ children, variant = "primary", onClick, type = "button", showArrow = true, square = false, disabled = false, }) {
    return (React.createElement("button", { type: type, className: `button button-${variant} ${square ? "button-square" : ""}`, onClick: onClick, disabled: disabled, style: disabled ? { opacity: 0.6, cursor: "not-allowed" } : undefined },
        children,
        showArrow && React.createElement(Icon, { name: "arrow", size: 17 })));
}
function Badge({ children, tone = "low", }) {
    const safeTone = tone === "pending" ? "low" : tone;
    return (React.createElement("span", { className: `badge badge-${safeTone}` },
        React.createElement("i", null),
        children));
}
function SectionHeading({ eyebrow, title, copy, center = false, }) {
    return (React.createElement("div", { className: `section-heading ${center ? "center" : ""}` },
        React.createElement("span", { className: "eyebrow" }, eyebrow),
        React.createElement("h2", null, title),
        copy && React.createElement("p", null, copy)));
}
function Card({ children, className = "", onClick, }) {
    return (React.createElement("article", { className: `card ${className} ${onClick ? "clickable" : ""}`, onClick: onClick }, children));
}
const journeySteps = ["Harvested", "Loaded", "In Transit", "Stored", "Buyer"];
const harvestSlides = [
    {
        image: "https://images.unsplash.com/photo-1758972574908-bc43ad077156?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1200",
        alt: "Heirloom tomatoes arranged in wooden harvest crates",
        label: "Fresh harvest",
        detail: "Haryana · Batch packed at 07:15",
    },
    {
        image: "https://images.unsplash.com/photo-1530541835461-dedaf9cf368a?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1200",
        alt: "Pathway between rows of tomato plants",
        label: "Source farm",
        detail: "Protected crop · Harvest verified",
    },
    {
        image: "https://images.unsplash.com/photo-1742805286691-04a69edc3874?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1200",
        alt: "Ripe tomatoes stacked in harvest crates",
        label: "Ready to move",
        detail: "Crate handling · Condition logged",
    },
];
const qrCells = Array.from({ length: 121 }, (_, i) => {
    const x = i % 11, y = Math.floor(i / 11);
    const finder = (x < 3 && y < 3) || (x > 7 && y < 3) || (x < 3 && y > 7);
    return finder || ((x * 7 + y * 3 + x * y) % 5 < 2);
});
function DashboardTable({ batches, selectedBatchId, onSelectBatch, openBuyer, query = "", cropFilter = "All crops", riskFilter = "All risk levels", onRefresh, loading = false, }) {
    const filteredBatches = useMemo(() => {
        return batches.filter((batch) => {
            const matchQuery = !query ||
                `${batch.batchNumber || batch.id} ${batch.crop} ${batch.origin} ${batch.destination}`
                    .toLowerCase()
                    .includes(query.toLowerCase());
            const matchCrop = cropFilter === "All crops" || batch.crop.toLowerCase() === cropFilter.toLowerCase();
            const matchRisk = riskFilter === "All risk levels" || batch.risk.toLowerCase() === riskFilter.toLowerCase();
            return matchQuery && matchCrop && matchRisk;
        });
    }, [batches, query, cropFilter, riskFilter]);
    return (React.createElement("div", { className: "table-wrap" },
        React.createElement("div", { className: "table-head table-row" },
            React.createElement("span", null, "Batch / Crop"),
            React.createElement("span", null, "Quantity"),
            React.createElement("span", null, "Origin \u2192 Destination"),
            React.createElement("span", null, "Journey progress"),
            React.createElement("span", null, "Temperature"),
            React.createElement("span", null, "Delay"),
            React.createElement("span", null, "Risk"),
            React.createElement("span", null, "Last updated")),
        loading && (React.createElement("div", { style: { padding: "32px", textAlign: "center", color: "var(--muted)", fontSize: "12px" } }, "Loading batches...")),
        !loading &&
            filteredBatches.map((batch) => {
                const isSelected = batch.id === selectedBatchId;
                const tone = batch.risk.toLowerCase() || "low";
                return (React.createElement("button", { className: `table-row data-row ${isSelected ? "selected-row" : ""}`, key: batch.id, onClick: () => {
                        onSelectBatch(batch);
                    }, style: isSelected
                        ? {
                            backgroundColor: "rgba(113,131,84,0.18)",
                            borderLeft: "3px solid var(--gold)",
                        }
                        : undefined },
                    React.createElement("span", { className: "batch-identity" },
                        React.createElement("i", null,
                            React.createElement("img", { src: batch.image || "assets/images/leaf-reference.png", alt: "" })),
                        React.createElement("span", null,
                            React.createElement("strong", null, batch.batchNumber || batch.id),
                            React.createElement("small", null,
                                batch.crop,
                                ""))),
                    React.createElement("span", { className: "quantity-cell" },
                        React.createElement("strong", null, batch.quantity),
                        React.createElement("small", null, batch.grade || "Grade A")),
                    React.createElement("span", { className: "route-cell" },
                        React.createElement("strong", null, batch.origin),
                        React.createElement("small", null,
                            React.createElement(Icon, { name: "arrow", size: 10 }),
                            " ",
                            batch.destination)),
                    React.createElement("span", { className: "progress-cell" },
                        React.createElement("span", null,
                            React.createElement("strong", null, batch.stage),
                            React.createElement("small", null,
                                batch.progress,
                                "%")),
                        React.createElement("i", null,
                            React.createElement("b", { style: { width: `${batch.progress}%` } }))),
                    React.createElement("span", { className: `condition-cell ${batch.temperature === "32°C" ? "hot" : ""}` },
                        React.createElement(Icon, { name: "temperature", size: 15 }),
                        React.createElement("strong", null, batch.temperature)),
                    React.createElement("span", { className: `delay-cell ${batch.delay && batch.delay !== "0 hrs" ? "delayed" : ""}` },
                        React.createElement(Icon, { name: "clock", size: 14 }),
                        React.createElement("strong", null, batch.delay || "0 hrs")),
                    React.createElement(Badge, { tone: tone }, batch.risk),
                    React.createElement("span", { className: "updated-cell" },
                        React.createElement("strong", null, batch.updated),
                        React.createElement("small", null, "Last update"))));
            }),
        !loading && filteredBatches.length === 0 && (React.createElement("div", { className: "empty-table", style: { padding: "40px 20px", textAlign: "center", color: "var(--muted)" } }, batches.length === 0
            ? "No crop batches yet. Create a batch to get started."
            : `No active batch matches “${query}”.`)),
        React.createElement("div", { className: "table-footer" },
            React.createElement("span", null,
                React.createElement("i", null),
                " Up to date"),
            React.createElement("button", { onClick: onRefresh, style: { display: "inline-flex", alignItems: "center", gap: "6px" } },
                "Refresh Batches ",
                React.createElement(Icon, { name: "refresh", size: 13 })))));
}
function BuyerSummary({ batch, compact = false, }) {
    const tone = batch.risk.toLowerCase() || "low";
    return (React.createElement(Card, { className: `buyer-summary ${compact ? "compact" : ""}` },
        React.createElement("div", { className: "buyer-summary-head" },
            React.createElement(Logo, null),
            React.createElement(Badge, { tone: tone }, batch.risk.toUpperCase())),
        React.createElement("span", { className: "micro" }, "CROPTRACE ID"),
        React.createElement("h3", null, batch.batchNumber || batch.id),
        React.createElement("div", { className: "summary-grid" },
            React.createElement("div", null,
                React.createElement("span", null, "Crop"),
                React.createElement("strong", null, batch.crop)),
            React.createElement("div", null,
                React.createElement("span", null, "Origin"),
                React.createElement("strong", null, batch.origin)),
            React.createElement("div", null,
                React.createElement("span", null, "Harvested"),
                React.createElement("strong", null, batch.harvestDate ? new Date(batch.harvestDate).toLocaleDateString() : "18 September 2026")),
            React.createElement("div", null,
                React.createElement("span", null, "Journey Duration"),
                React.createElement("strong", null, "18 hrs"))),
        React.createElement("div", { className: "summary-checks" },
            React.createElement("span", null,
                React.createElement(Icon, { name: "check", size: 15 }),
                " Journey History"),
            React.createElement("span", null,
                React.createElement(Icon, { name: "check", size: 15 }),
                " Condition Summary"),
            React.createElement("span", null,
                React.createElement(Icon, { name: "check", size: 15 }),
                " Risk Status"))));
}
function CreateBatchModal({ close, onBatchCreated, }) {
    const [done, setDone] = useState(false);
    const [createdBatchId, setCreatedBatchId] = useState("");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [crop, setCrop] = useState("Tomato");
    const [quantity, setQuantity] = useState("420 kg");
    const [origin, setOrigin] = useState("Haryana Farm");
    const [destination, setDestination] = useState("Delhi NCR");
    const [harvestDate, setHarvestDate] = useState("2026-09-18T06:30");
    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError(null);
        try {
            const created = await api.createBatch({
                crop,
                quantity,
                origin,
                destination,
                harvestDate,
                grade: "Grade A",
            });
            setCreatedBatchId(created.batchNumber || created.id);
            setDone(true);
            onBatchCreated(created);
        }
        catch (err) {
            console.error("Batch creation failed:", err);
            setError(err.message || "Failed to create batch. Please check required fields.");
        }
        finally {
            setLoading(false);
        }
    };
    return (React.createElement("div", { className: "modal-backdrop", role: "dialog", "aria-modal": "true", "aria-label": "Create a crop batch" },
        React.createElement("div", { className: "modal" },
            React.createElement("button", { className: "modal-close", onClick: close, "aria-label": "Close" },
                React.createElement(Icon, { name: "close" })),
            done ? (React.createElement("div", { className: "success-state" },
                React.createElement("span", null,
                    React.createElement(Icon, { name: "check", size: 28 })),
                React.createElement("p", { className: "eyebrow" }, "BATCH CREATED"),
                React.createElement("h2", null,
                    createdBatchId,
                    " is ready to track."),
                React.createElement("p", null, "The initial harvest event has been logged and tracking has started."),
                React.createElement(Button, { onClick: close }, "View new batch"))) : (React.createElement(React.Fragment, null,
                React.createElement("span", { className: "eyebrow" }, "NEW BATCH"),
                React.createElement("h2", null, "Create a batch"),
                React.createElement("p", null, "Enter the harvest essentials to start tracking this batch."),
                error && (React.createElement("div", { style: {
                        marginTop: "12px",
                        padding: "10px",
                        background: "rgba(151,85,62,0.25)",
                        border: "1px solid rgba(151,85,62,0.4)",
                        borderRadius: "8px",
                        color: "#e8997a",
                        fontSize: "12px",
                    } }, error)),
                React.createElement("form", { onSubmit: handleSubmit },
                    React.createElement("label", null,
                        React.createElement("span", null, "Crop"),
                        React.createElement("select", { value: crop, onChange: (e) => setCrop(e.target.value) },
                            React.createElement("option", { value: "Tomato" }, "Tomato"),
                            React.createElement("option", { value: "Potato" }, "Potato"),
                            React.createElement("option", { value: "Onion" }, "Onion"))),
                    React.createElement("label", null,
                        React.createElement("span", null, "Quantity"),
                        React.createElement("input", { required: true, value: quantity, onChange: (e) => setQuantity(e.target.value), placeholder: "e.g. 420 kg" })),
                    React.createElement("label", null,
                        React.createElement("span", null, "Origin"),
                        React.createElement("input", { required: true, value: origin, onChange: (e) => setOrigin(e.target.value), placeholder: "e.g. Haryana Farm" })),
                    React.createElement("label", null,
                        React.createElement("span", null, "Destination"),
                        React.createElement("input", { required: true, value: destination, onChange: (e) => setDestination(e.target.value), placeholder: "e.g. Delhi NCR" })),
                    React.createElement("label", { className: "full" },
                        React.createElement("span", null, "Harvest date & time"),
                        React.createElement("input", { type: "datetime-local", value: harvestDate, onChange: (e) => setHarvestDate(e.target.value), required: true })),
                    React.createElement("div", { className: "form-actions full" },
                        React.createElement(Button, { variant: "secondary", onClick: close, disabled: loading }, "Cancel"),
                        React.createElement(Button, { type: "submit", disabled: loading }, loading ? "Saving..." : "Create batch"))))))));
}
function BuyerModal({ batch, events, close, }) {
    const S = window.CropTraceScreens;
    return (React.createElement("div", { className: "modal-backdrop", role: "dialog", "aria-modal": "true", "aria-label": "Buyer verification" },
        React.createElement("div", { className: "modal buyer-modal" },
            React.createElement("button", { className: "modal-close", onClick: close, "aria-label": "Close" }, React.createElement(Icon, { name: "close" })),
            React.createElement(S.Verify, { batch: batch, events: events, modal: true }))));
}
function AddEventModal({ batch, close, onEventAdded, }) {
    const [stage, setStage] = useState("In Transit");
    const [location, setLocation] = useState(batch.origin + " Gateway");
    const [actor, setActor] = useState("Logistics Officer");
    const [notes, setNotes] = useState("Produce inspection verified; dispatch continuous.");
    const [temperature, setTemperature] = useState(batch.temperature || "27.4°C");
    const [loading, setLoading] = useState(false);
    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            const newEvt = await api.createTraceabilityEvent({
                batchId: batch.id,
                stage,
                location,
                actor,
                notes,
                temperature,
                risk: stage === "Delay detected" ? "WATCH" : "LOW",
                tone: stage === "Delay detected" ? "watch" : "low",
            });
            onEventAdded(newEvt);
            close();
        }
        catch (err) {
            console.error("Failed to add event:", err);
        }
        finally {
            setLoading(false);
        }
    };
    return (React.createElement("div", { className: "modal-backdrop", role: "dialog", "aria-modal": "true", "aria-label": "Log Journey Event" },
        React.createElement("div", { className: "modal" },
            React.createElement("button", { className: "modal-close", onClick: close, "aria-label": "Close" },
                React.createElement(Icon, { name: "close" })),
            React.createElement("span", { className: "eyebrow" }, "TRACEABILITY LOG"),
            React.createElement("h2", null, "Add Journey Event"),
            React.createElement("p", null,
                "Record a new stage or transit transition for Batch #",
                batch.batchNumber || batch.id,
                "."),
            React.createElement("form", { onSubmit: handleSubmit },
                React.createElement("label", null,
                    React.createElement("span", null, "Stage"),
                    React.createElement("select", { value: stage, onChange: (e) => setStage(e.target.value) },
                        React.createElement("option", { value: "Harvested" }, "Harvested"),
                        React.createElement("option", { value: "Loaded" }, "Loaded"),
                        React.createElement("option", { value: "In Transit" }, "In Transit"),
                        React.createElement("option", { value: "Delay Detected" }, "Delay Detected"),
                        React.createElement("option", { value: "Storage" }, "Storage"),
                        React.createElement("option", { value: "Buyer" }, "Buyer"))),
                React.createElement("label", null,
                    React.createElement("span", null, "Temperature"),
                    React.createElement("input", { value: temperature, onChange: (e) => setTemperature(e.target.value), placeholder: "e.g. 27.5\u00B0C" })),
                React.createElement("label", null,
                    React.createElement("span", null, "Location"),
                    React.createElement("input", { required: true, value: location, onChange: (e) => setLocation(e.target.value) })),
                React.createElement("label", null,
                    React.createElement("span", null, "Actor / Operator"),
                    React.createElement("input", { required: true, value: actor, onChange: (e) => setActor(e.target.value) })),
                React.createElement("label", { className: "full" },
                    React.createElement("span", null, "Notes"),
                    React.createElement("input", { value: notes, onChange: (e) => setNotes(e.target.value) })),
                React.createElement("div", { className: "form-actions full" },
                    React.createElement(Button, { variant: "secondary", onClick: close }, "Cancel"),
                    React.createElement(Button, { type: "submit", disabled: loading }, loading ? "Recording..." : "Record Event"))))));
}
function WorkspaceHeading({ label, title, copy, action, }) {
    return (React.createElement("div", { className: "workspace-heading" },
        React.createElement("div", null,
            React.createElement("span", null, label),
            React.createElement("h2", null, title),
            React.createElement("p", null, copy)),
        action));
}
function ProductApp({ view, routeId, go, onLogout }) {
    const V = window.CropTraceViews;
    var _a, _b, _c, _d;
    const [menuOpen, setMenuOpen] = useState(false);
    const [modal, setModal] = useState(null);
    const [searchQuery, setSearchQuery] = useState("");
    const [cropFilter, setCropFilter] = useState("All crops");
    const [riskFilter, setRiskFilter] = useState("All risk levels");
    const [notificationsOpen, setNotificationsOpen] = useState(false);
    const [profileOpen, setProfileOpen] = useState(false);
    // Real backend state
    const [batches, setBatches] = useState([]);
    const [selectedBatchId, setSelectedBatchId] = useState("CT-2841");
    const [traceabilityEvents, setTraceabilityEvents] = useState([]);
    const [allEvents, setAllEvents] = useState([]);
    const [dashboardStats, setDashboardStats] = useState(null);
    const [notifications, setNotifications] = useState([]);
    const [loading, setLoading] = useState(true);
    const [seedLoading, setSeedLoading] = useState(false);
    const [syncStatus, setSyncStatus] = useState("\u2014");
    const S = window.CropTraceScreens;
    const [acting, setActing] = useState(false);
    const [simulating, setSimulating] = useState(false);
    const [simMsg, setSimMsg] = useState("");
    const markAction = async (bid) => {
        setActing(true);
        try { await api.updateBatch(bid || selectedBatchId, { actionTaken: true, risk: "Low", riskScore: 24, recommendedAction: "Moved to shaded holding bay; conditions rechecked." }); await loadInitialData(); }
        catch (err) { console.error(err); }
        finally { setActing(false); }
    };
    const simulateReading = async () => {
        setSimulating(true); setSimMsg("");
        try {
            const t = Number((26 + Math.random() * 7).toFixed(1)), hu = Number((62 + Math.random() * 14).toFixed(0));
            await api.postSensorReading({ deviceId: "DEMO-NODE-01", batchId: selectedBatchId, temperature: t, humidity: hu, isSimulated: true });
            setSimMsg("Simulated reading saved: " + t + "\u00B0C, " + hu + "% RH. Risk recalculated by the rule engine.");
            await loadInitialData();
        } catch (err) { setSimMsg("Could not save reading: " + err.message); }
        finally { setSimulating(false); }
    };
    // Sidebar ids -> route names. Navigation is done with go() (hash routing), not scrolling.
    const sectionRoutes = { dashboard: "dashboard", "live-journey": "journey", batches: "batches", "risk-monitor": "risk", "climate-context": "climate", buyers: "buyers", traceability: "traceability" };
    const scrollTo = (id) => {
        setMenuOpen(false);
        const v = sectionRoutes[id] || "dashboard";
        go(v === "journey" || v === "traceability" ? v + "/" + selectedBatchId : v);
    };
    // keep the selected batch in sync with the URL (#/journey/CT-2841)
    useEffect(() => { if (routeId) setSelectedBatchId(routeId); }, [routeId]);
    // Load batches and dashboard data from real backend
    const loadInitialData = async () => {
        setLoading(true);
        try {
            api.getAllTraceability().then(setAllEvents).catch(() => { });
            const [fetchedBatches, fetchedStats, fetchedNotifs] = await Promise.all([
                api.getBatches(),
                api.getDashboard().catch(() => null),
                api.getNotifications().catch(() => []),
            ]);
            if (fetchedBatches.length > 0) {
                setBatches(fetchedBatches);
                if (!fetchedBatches.some((b) => b.id === selectedBatchId)) {
                    setSelectedBatchId(fetchedBatches[0].id);
                }
            }
            else {
                // Empty state in database
                setBatches([]);
            }
            if (fetchedStats)
                setDashboardStats(fetchedStats);
            if (fetchedNotifs)
                setNotifications(fetchedNotifs);
            setSyncStatus(`${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`);
        }
        catch (err) {
            console.error("Failed to load initial data from local store:", err);
            setSyncStatus("Unavailable");
        }
        finally {
            setLoading(false);
        }
    };
    useEffect(() => {
        loadInitialData();
    }, []);
    // Fetch traceability events whenever selectedBatchId changes
    useEffect(() => {
        if (!selectedBatchId)
            return;
        api
            .getTraceability(selectedBatchId)
            .then((events) => {
            setTraceabilityEvents(events);
        })
            .catch((err) => {
            console.warn("Could not fetch traceability events for", selectedBatchId, err);
        });
    }, [selectedBatchId]);
    const selectedBatch = useMemo(() => {
        return (batches.find((b) => b.id === selectedBatchId) ||
            batches[0] || {
            id: "CT-2841",
            batchNumber: "CT-2841",
            crop: "Tomato",
            variety: "Heirloom Grade A",
            quantity: "420 kg",
            origin: "Haryana Farm",
            destination: "Delhi NCR",
            stage: "In transit",
            progress: 68,
            temperature: "27°C",
            temperatureVal: 27.4,
            humidity: "68%",
            delay: "0 hrs",
            risk: "Low",
            riskScore: 24,
            updated: "12 min ago",
            image: "https://images.unsplash.com/photo-1682432682898-5438b8ed6985?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=80&w=300",
            createdAt: new Date().toISOString(),
        });
    }, [batches, selectedBatchId]);
    // Seed demo data mechanism
    const handleSeedDemoData = async () => {
        setSeedLoading(true);
        try {
            await api.seedDemoData();
            await loadInitialData();
        }
        catch (err) {
            console.error("Failed to seed demo data:", err);
        }
        finally {
            setSeedLoading(false);
        }
    };
    const navGroups = [
        { label: "OVERVIEW", items: [{ label: "Dashboard", id: "dashboard", icon: "batch" }] },
        {
            label: "TRACKING",
            items: [
                { label: "Batch Journey", id: "live-journey", icon: "route" },
                { label: "Batches", id: "batches", icon: "database" },
            ],
        },
        {
            label: "INTELLIGENCE",
            items: [
                { label: "Risk Monitor", id: "risk-monitor", icon: "risk" },
                { label: "Climate Context", id: "climate-context", icon: "weather" },
            ],
        },
        {
            label: "NETWORK",
            items: [
                { label: "Buyers", id: "buyers", icon: "user" },
                { label: "Traceability", id: "traceability", icon: "scan" },
            ],
        },
    ];
    return (React.createElement("div", { className: "product-app" },
        React.createElement("aside", { className: `product-sidebar ${menuOpen ? "open" : ""}` },
            React.createElement("div", { className: "sidebar-brand" },
                React.createElement(Logo, null),
                React.createElement("p", null, "Post-harvest intelligence")),
            React.createElement("nav", { className: "sidebar-nav" }, navGroups.map((group) => (React.createElement("div", { className: "sidebar-group", key: group.label },
                React.createElement("span", null, group.label),
                group.items.map((item) => (React.createElement("button", { className: sectionRoutes[item.id] === view ? "active" : "", onClick: () => scrollTo(item.id), key: item.id },
                    React.createElement(Icon, { name: item.icon, size: 17 }),
                    item.label,
                    React.createElement("i", null)))))))),
            React.createElement("button", { className: "sidebar-settings sidebar-logout", onClick: onLogout }, "Log out"),
            React.createElement("div", { className: "sidebar-system" },
                React.createElement("span", null, React.createElement("i", null), " Farm Operations"),
                React.createElement("small", null, "Last updated ", syncStatus))),
        menuOpen && (React.createElement("button", { className: "sidebar-scrim", onClick: () => setMenuOpen(false), "aria-label": "Close navigation" })),
        React.createElement("div", { className: "product-shell" },
            React.createElement("header", { className: "product-topbar" },
                React.createElement("button", { className: "mobile-sidebar-toggle", onClick: () => setMenuOpen(!menuOpen), "aria-label": "Toggle sidebar" },
                    React.createElement(Icon, { name: menuOpen ? "close" : "menu" })),
                React.createElement("div", { className: "topbar-context" },
                    React.createElement("span", null, "WORKSPACE"),
                    React.createElement("strong", null, "Farm Operations")),
                React.createElement("label", { className: "product-search" },
                    React.createElement(Icon, { name: "search", size: 17 }),
                    React.createElement("input", { value: searchQuery, onChange: (event) => { setSearchQuery(event.target.value); if (view !== "batches") go("batches"); }, placeholder: "Search batches, crops or locations" })),
                React.createElement("div", { className: "topbar-actions" },
                    view !== "dashboard" && React.createElement("button", { className: "topbar-text-btn", onClick: () => window.history.back() }, "\u2190 Back"),
                    React.createElement("button", { className: "topbar-text-btn", onClick: onLogout }, "Log out"),
                    React.createElement("div", { className: "notification-wrap" },
                        React.createElement("button", { className: "topbar-icon", onClick: () => setNotificationsOpen(!notificationsOpen), "aria-label": "Notifications" },
                            React.createElement(Icon, { name: "bell", size: 18 }),
                            React.createElement("i", null)),
                        notificationsOpen && (React.createElement("div", { className: "notification-popover" },
                            React.createElement("span", null, "NOTIFICATIONS"),
                            notifications.length > 0 ? (notifications.map((n) => (React.createElement("div", { key: n.id, style: { marginBottom: "10px" } },
                                React.createElement("strong", null, n.title),
                                React.createElement("p", null, n.message),
                                React.createElement("small", null, n.timeAgo))))) : (React.createElement("p", null, "No new notifications."))))),
                    React.createElement("div", { className: "profile-wrap" },
                        React.createElement("button", { className: "profile-area", onClick: () => setProfileOpen(!profileOpen), "aria-label": "Account menu" },
                            React.createElement("span", null, "AK"),
                            React.createElement("div", null,
                                React.createElement("strong", null, "Arjun Kumar"),
                                React.createElement("small", null, "Farm operator"))),
                        profileOpen && React.createElement("div", { className: "profile-menu" },
                            React.createElement("button", { onClick: onLogout }, "Log out"),
                            React.createElement("button", { onClick: () => { if (window.confirm("Reset all workspace data to its original state?")) { api.resetLocalData(); window.location.reload(); } } }, "Reset workspace data"))))),
            React.createElement("main", { className: "product-main" },
                ["traceability", "climate"].includes(view) && batches.length > 0 && React.createElement(V.BatchPicker, { batches: batches, selectedId: selectedBatch.id, onPick: (id) => go(view + "/" + id) }),
                view === "dashboard" && React.createElement(S.Dashboard, { batches: batches, stats: dashboardStats, events: allEvents, loading: loading, go: go, selectedId: selectedBatchId, onCreate: () => setModal("create"), onSeed: handleSeedDemoData, onAction: markAction, acting: acting }),
                view === "journey" && (loading ? React.createElement(S.Loading, { text: "Loading batch\u2026" }) : batches.length === 0 ? React.createElement(S.Empty, { icon: "batch", title: "No batches yet", text: "Create a batch to see its journey here.", action: React.createElement(Button, { showArrow: false, onClick: () => setModal("create") }, "Create a batch") }) : React.createElement(S.BatchDetail, { batch: selectedBatch, events: traceabilityEvents, go: go, onVerify: () => go("verify/" + selectedBatch.id), onAddEvent: () => setModal("add-event"), onMarkAction: () => markAction(selectedBatchId), onAction: markAction, acting: acting, onSimulate: simulateReading, simulating: simulating, simMsg: simMsg })),
                view === "batches" && React.createElement("section", { className: "workspace-section", id: "batches", "data-dashboard-section": true },
                    React.createElement(WorkspaceHeading, { label: "BATCH TRACKING", title: "Active batches", copy: "Monitor every active crop movement and identify batches that need attention.", action: React.createElement(Button, { showArrow: false, onClick: () => setModal("create") }, "New Batch") }),
                    React.createElement("div", { className: "batch-table-card workspace-table-card" },
                        React.createElement("div", { className: "table-title" },
                            React.createElement("div", null,
                                React.createElement("span", { className: "micro" }, "OPERATIONS MONITOR"),
                                React.createElement("h3", null, "Active batch monitoring"),
                                React.createElement("p", null, "Current conditions across active farm-to-buyer movements.")),
                            React.createElement("div", { className: "table-controls" },
                                React.createElement("select", { value: cropFilter, onChange: (e) => setCropFilter(e.target.value), style: {
                                        background: "rgba(8,19,13,0.46)",
                                        border: "1px solid var(--border)",
                                        color: "#aaa18d",
                                        borderRadius: "7px",
                                        padding: "0 10px",
                                        fontSize: "9px",
                                        minHeight: "34px",
                                    } },
                                    React.createElement("option", { value: "All crops" }, "All crops"),
                                    React.createElement("option", { value: "Tomato" }, "Tomato"),
                                    React.createElement("option", { value: "Potato" }, "Potato"),
                                    React.createElement("option", { value: "Onion" }, "Onion")),
                                React.createElement("select", { value: riskFilter, onChange: (e) => setRiskFilter(e.target.value), style: {
                                        background: "rgba(8,19,13,0.46)",
                                        border: "1px solid var(--border)",
                                        color: "#aaa18d",
                                        borderRadius: "7px",
                                        padding: "0 10px",
                                        fontSize: "9px",
                                        minHeight: "34px",
                                    } },
                                    React.createElement("option", { value: "All risk levels" }, "All risk levels"),
                                    React.createElement("option", { value: "Low" }, "Low"),
                                    React.createElement("option", { value: "Watch" }, "Watch"),
                                    React.createElement("option", { value: "High" }, "High")),
                                React.createElement("button", { className: "icon-control", onClick: loadInitialData, "aria-label": "Refresh dashboard" },
                                    React.createElement(Icon, { name: "refresh", size: 15 })))),
                        React.createElement(DashboardTable, { batches: batches, selectedBatchId: selectedBatch.id, onSelectBatch: (batch) => go("journey/" + batch.id), openBuyer: () => setModal("buyer"), query: searchQuery, cropFilter: cropFilter, riskFilter: riskFilter, onRefresh: loadInitialData, loading: loading }))),
                view === "risk" && React.createElement(S.RiskMonitor, { batches: batches, loading: loading, go: go, onAction: markAction, acting: acting }),
                view === "climate" && (batches.length === 0 ? React.createElement(S.Empty, { icon: "weather", title: "No batches yet", text: "Climate context is shown for a selected batch." }) : React.createElement(S.Climate, { batch: selectedBatch })),
                view === "buyers" && React.createElement(S.Buyers, { batches: batches, go: go }),
                view === "traceability" && (batches.length === 0 ? React.createElement(S.Empty, { icon: "clock", title: "No journey events", text: "Create a batch to start a traceability timeline." }) : React.createElement(S.Timeline, { batch: selectedBatch, events: traceabilityEvents, onAddEvent: () => setModal("add-event") }))),
            React.createElement("footer", { className: "product-footer" },
                React.createElement("div", null,
                    React.createElement(Logo, null),
                    React.createElement("p", null, "Making the post-harvest journey more visible.")),
                React.createElement("span", null, "\u00A9 2026 CropTrace"),
                React.createElement("span", null, "Farm to buyer, one verified record"))),
        modal === "create" && (React.createElement(CreateBatchModal, { close: () => setModal(null), onBatchCreated: (newBatch) => {
                setBatches((prev) => [newBatch, ...prev]);
                setSelectedBatchId(newBatch.id);
                loadInitialData();
            } })),
        modal === "buyer" && (React.createElement(BuyerModal, { batch: selectedBatch, events: traceabilityEvents, close: () => setModal(null) })),
        modal === "add-event" && (React.createElement(AddEventModal, { batch: selectedBatch, close: () => setModal(null), onEventAdded: (newEvt) => {
                setTraceabilityEvents((prev) => [...prev, newEvt]);
                loadInitialData();
            } }))));
}

// ---- Top-level app: hash routing (#/login, #/dashboard, #/journey/CT-2841 ...) + demo login ----
const APP_VIEWS = ["dashboard", "batches", "journey", "risk", "climate", "buyers", "traceability"];
function parseHash() {
    const parts = (window.location.hash || "").replace(/^#\/?/, "").split("/").filter(Boolean);
    return { view: parts[0] || "landing", id: parts[1] ? decodeURIComponent(parts[1]) : null };
}
function isAuthed() {
    try { return !!(localStorage.getItem("croptrace_session") || sessionStorage.getItem("croptrace_session")); }
    catch (e) { return false; }
}
function VerifyPage({ id, go }) {
    const S = window.CropTraceScreens, V = window.CropTraceViews;
    const [state, setState] = useState({ batch: null, events: [], done: false });
    useEffect(() => { Promise.all([api.getBatchById(id), api.getTraceability(id)]).then(([batch, events]) => setState({ batch, events, done: true })).catch(() => setState({ batch: null, events: [], done: true })); }, [id]);
    return React.createElement("div", { className: "verify-page" },
        React.createElement("header", { className: "verify-bar" }, React.createElement(Logo, null), React.createElement(Button, { variant: "secondary", showArrow: false, onClick: () => go(isAuthed() ? "journey/" + id : "") }, isAuthed() ? "Back to batch" : "Home")),
        !state.done ? React.createElement(S.Loading, { text: "Verifying batch\u2026" }) : !state.batch ? React.createElement(S.Empty, { icon: "scan", title: "Batch not found", text: "No record exists for " + id + " in this demo." }) : React.createElement(S.Verify, { batch: state.batch, events: state.events }));
}
function Root() {
    const [route, setRoute] = useState(parseHash());
    const [authed, setAuthed] = useState(isAuthed());
    useEffect(() => {
        const onHash = () => { setRoute(parseHash()); window.scrollTo(0, 0); };
        window.addEventListener("hashchange", onHash);
        return () => window.removeEventListener("hashchange", onHash);
    }, []);
    const go = (path) => { window.location.hash = "/" + path; };
    const login = (email, remember) => {
        try { (remember ? localStorage : sessionStorage).setItem("croptrace_session", JSON.stringify({ email })); } catch (e) { }
        setAuthed(true);
        window.location.replace("#/dashboard"); // replace so Back doesn't return to the login screen
    };
    const logout = () => {
        try { localStorage.removeItem("croptrace_session"); sessionStorage.removeItem("croptrace_session"); } catch (e) { }
        window.location.hash = "/";
        setRoute({ view: "landing", id: null });
        setAuthed(false);
    };
    const V = window.CropTraceViews;
    const guarded = APP_VIEWS.includes(route.view) && !authed;
    useEffect(() => { if (guarded) window.location.replace("#/login"); }, [guarded]);
    useEffect(() => { if (route.view === "login" && authed) window.location.replace("#/dashboard"); }, [route.view, authed]);
    if (route.view === "verify" && route.id) return React.createElement(VerifyPage, { id: route.id, go: go });
    if (route.view === "login" || guarded) return React.createElement(V.Login, { go: go, onLogin: login });
    if (APP_VIEWS.includes(route.view))
        return React.createElement(ProductApp, { view: route.view, routeId: route.id, go: go, onLogout: logout });
    return React.createElement(V.Landing, { go: go, authed: authed });
}

var root=ReactDOMClient.createRoot(document.getElementById('root'));
root.render(React.createElement(exports.default));
})();
