/* CropTrace extra screens: Landing, Login, and the new dashboard views.
   Everything here reads from the SAME data as the rest of the app (data/data.js + js/api.js),
   so a batch looks identical on every screen. Loaded before app.js. */
(function () {
  var React = window.React, h = React.createElement, useState = React.useState;
  var D = window.CROPTRACE_DATA || {};
  function UI() { return window.CropTraceUI; } // Icon, Logo, Button, Badge, Card, WorkspaceHeading (set by app.js)

  /* ---------- shared helpers (rule-based demo logic, NOT real AI) ---------- */
  function num(s) { var m = String(s || '').match(/-?\d+(\.\d+)?/); return m ? parseFloat(m[0]) : 0; }
  function tone(b) { return String(b.risk || 'Low').toLowerCase(); }

  function riskReasons(b) {
    var r = [], t = b.temperatureVal || num(b.temperature), d = num(b.delay), hum = num(b.humidity);
    if (t > 30) r.push('Temperature above recommended range (' + t.toFixed(1) + '°C vs 30°C limit)');
    if (d >= 1) r.push('Transit delay detected (' + b.delay + ')');
    if (hum > 70) r.push('Humidity above 70% (' + b.humidity + ')');
    if (b.stage === 'In storage' && b.risk === 'High') r.push('Held at ambient heat; near shelf-life loss threshold');
    if (!r.length) r.push('All readings within recommended range');
    return r;
  }

  function climateFor(b) {
    var c = (D.DEMO_CLIMATE && D.DEMO_CLIMATE[b.id]) || { location: b.origin, weather: 'Clear', rainProb: 10 };
    var t = b.temperatureVal || num(b.temperature), hum = num(b.humidity);
    var status = 'No major weather risk';
    if (t > 30) status = 'Heat exposure - shade and expedite';
    else if (c.rainProb >= 50) status = 'Rain risk on route';
    else if (hum > 70) status = 'High humidity - watch for moisture loss';
    return { location: c.location, weather: c.weather, rainProb: c.rainProb, status: status, temperature: b.temperature,
      humidity: b.humidity, humidityLabel: hum > 70 ? 'High humidity' : hum < 50 ? 'Low humidity' : 'Moderate humidity' };
  }

  function buyersWithStats(batches) {
    return (D.DEMO_BUYERS || []).map(function (by) {
      var bs = batches.filter(function (b) { return by.destinations.indexOf(b.destination) >= 0; });
      var active = bs.filter(function (b) { return b.stage !== 'Delivered'; }).length;
      var delivered = bs.filter(function (b) { return b.stage === 'Delivered'; }).length;
      var hasHigh = bs.some(function (b) { return b.risk === 'High'; });
      return Object.assign({}, by, { batches: bs, activeOrders: active, received: by.receivedBase + delivered,
        status: hasHigh ? 'Attention needed' : active > 0 ? 'Receiving' : 'Idle', statusTone: hasHigh ? 'high' : active > 0 ? 'low' : 'watch' });
    });
  }

  function nav(id) { var el = document.getElementById(id); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' }); }

  /* ---------- Batch picker (keeps the same selected batch across screens) ---------- */
  function BatchPicker(p) {
    return h('div', { className: 'bp-row' }, h('span', null, 'BATCH'),
      p.batches.map(function (b) {
        return h('button', { key: b.id, className: b.id === p.selectedId ? 'active' : '', onClick: function () { p.onPick(b.id); } },
          b.id, h('small', null, b.crop));
      }));
  }

  /* ---------- Dashboard: operations snapshot ---------- */
  function DashboardExtras(p) {
    var ui = UI(), Card = ui.Card, Badge = ui.Badge, b = p.batches;
    var alerts = b.filter(function (x) { return x.risk === 'Watch' || x.risk === 'High'; });
    var harvests = b.slice().sort(function (x, y) { return String(y.harvestDate).localeCompare(String(x.harvestDate)); }).slice(0, 4);
    var completed = b.filter(function (x) { return x.stage === 'Delivered'; }).length;
    var journey = function (id) { p.go('journey/' + id); };
    function panel(title, label, onAll, rows) {
      return h(Card, { className: 'dx-panel' }, h('div', { className: 'dx-head' }, h('div', null, h('span', { className: 'micro' }, label), h('h3', null, title)),
        h('button', { className: 'dx-link', onClick: onAll }, 'View all')), h('div', { className: 'dx-list' }, rows));
    }
    return h('section', { className: 'workspace-section' },
      ui.WorkspaceHeading({ label: 'OPERATIONS SNAPSHOT', title: 'What needs attention today',
        copy: p.batches.length + ' batches tracked \u00B7 ' + completed + ' completed \u00B7 ' + alerts.length + ' need attention.',
        action: h(ui.Button, { showArrow: false, variant: 'secondary', onClick: function () { p.go('buyers'); } }, 'Open Buyers') }),
      h('div', { className: 'dx-grid' },
        panel('Recent activity', 'LATEST EVENTS', function () { p.go('traceability'); },
          (p.events || []).slice(0, 5).map(function (e) {
            return h('button', { key: e.id, className: 'dx-row', onClick: function () { journey(e.batchId); } },
              h('strong', null, e.batchId + ' \u00B7 ' + e.stage), h('small', null, e.location + ' \u00B7 ' + e.time));
          })),
        panel('Risk alerts', 'RULE-BASED', function () { p.go('risk'); },
          alerts.length ? alerts.map(function (x) {
            return h('button', { key: x.id, className: 'dx-row', onClick: function () { p.go('risk'); } },
              h('strong', null, x.id + ' \u00B7 ' + x.crop), h(Badge, { tone: tone(x) }, x.risk.toUpperCase()), h('small', null, riskReasons(x)[0]));
          }) : h('p', { className: 'dx-empty' }, 'No active alerts.')),
        panel('Climate conditions', 'ALONG THE ROUTE', function () { p.go('climate'); },
          b.slice(0, 4).map(function (x) {
            var c = climateFor(x);
            return h('button', { key: x.id, className: 'dx-row', onClick: function () { p.go('climate'); } },
              h('strong', null, x.id + ' \u00B7 ' + c.location), h('small', null, c.temperature + ' \u00B7 ' + x.humidity + ' RH \u00B7 ' + c.weather));
          })),
        panel('Recent harvests', 'NEWEST FIRST', function () { p.go('batches'); },
          harvests.map(function (x) {
            return h('button', { key: x.id, className: 'dx-row', onClick: function () { journey(x.id); } },
              h('strong', null, x.crop + ' \u00B7 ' + x.id), h('small', null, x.quantity + ' \u00B7 ' + (x.grade || '') + ' \u00B7 ' + x.origin));
          }))));
  }

  /* ---------- Risk Monitor: LOW / WATCH / HIGH board ---------- */
  function RiskBoard(p) {
    var ui = UI(), Card = ui.Card, Badge = ui.Badge;
    return h('section', { className: 'workspace-section' },
      ui.WorkspaceHeading({ label: 'ALL BATCHES', title: 'Risk by level',
        copy: 'Rule-based demo logic (temperature, delay, humidity). This is not an AI prediction.' }),
      h('div', { className: 'rb-grid' }, ['Low', 'Watch', 'High'].map(function (level) {
        var list = p.batches.filter(function (x) { return x.risk === level; });
        return h('div', { className: 'rb-col', key: level },
          h('div', { className: 'rb-col-head' }, h(Badge, { tone: level.toLowerCase() }, level.toUpperCase()), h('span', null, list.length + ' batch' + (list.length === 1 ? '' : 'es'))),
          list.length ? list.map(function (x) {
            return h(Card, { key: x.id, className: 'rb-card', onClick: function () { p.go('journey/' + x.id); } },
              h('div', { className: 'rb-title' }, h('strong', null, x.id), h('small', null, x.crop + ' \u00B7 ' + x.origin)),
              h('span', { className: 'micro' }, 'REASON'),
              h('ul', null, riskReasons(x).map(function (r) { return h('li', { key: r }, r); })),
              h('em', null, 'Open journey \u2192'));
          }) : h('p', { className: 'dx-empty' }, 'No batches at this level.'));
      })));
  }

  /* ---------- Climate Context: every batch ---------- */
  function ClimateBoard(p) {
    var ui = UI(), Card = ui.Card;
    return h('section', { className: 'workspace-section' },
      ui.WorkspaceHeading({ label: 'ALL BATCHES', title: 'Environment by batch', copy: 'Sample climate data linked to each batch. Click a card to focus it above.' }),
      h('div', { className: 'cb-grid' }, p.batches.map(function (x) {
        var c = climateFor(x);
        return h(Card, { key: x.id, className: 'cb-card ' + (x.id === p.selectedId ? 'selected' : ''), onClick: function () { p.onSelect(x.id); } },
          h('span', { className: 'micro' }, x.crop + ' Batch #' + x.id), h('h3', null, c.location),
          h('div', { className: 'cb-stats' },
            h('div', null, h('small', null, 'Temp'), h('strong', null, c.temperature)),
            h('div', null, h('small', null, 'Humidity'), h('strong', null, c.humidity)),
            h('div', null, h('small', null, 'Rain'), h('strong', null, c.rainProb + '%'))),
          h('p', null, c.humidityLabel + ' \u00B7 ' + c.weather), h('em', null, c.status),
          h('button', { className: 'dx-link', onClick: function (e) { e.stopPropagation(); p.go('journey/' + x.id); } }, 'View journey'));
      })));
  }

  /* ---------- Buyers ---------- */
  function BuyersView(p) {
    var ui = UI(), Card = ui.Card, Badge = ui.Badge;
    var buyers = buyersWithStats(p.batches), st = useState(buyers[0] && buyers[0].id), sel = st[0], setSel = st[1];
    var cur = buyers.filter(function (x) { return x.id === sel; })[0] || buyers[0];
    return h('section', { className: 'workspace-section' },
      ui.WorkspaceHeading({ label: 'BUYER NETWORK', title: 'Buyers and receivers', copy: 'Select a buyer to see the batches heading their way.' }),
      h('div', { className: 'bv-grid' }, buyers.map(function (x) {
        return h(Card, { key: x.id, className: 'bv-card ' + (x.id === (cur && cur.id) ? 'selected' : ''), onClick: function () { setSel(x.id); } },
          h('div', { className: 'bv-top' }, h('div', null, h('h3', null, x.name), h('small', null, x.location + ' \u00B7 ' + x.type)), h(Badge, { tone: x.statusTone }, x.status.toUpperCase())),
          h('div', { className: 'cb-stats' },
            h('div', null, h('small', null, 'Active orders'), h('strong', null, x.activeOrders)),
            h('div', null, h('small', null, 'Received batches'), h('strong', null, x.received))));
      })),
      cur && h(Card, { className: 'bv-detail' },
        h('span', { className: 'micro' }, 'BATCHES FOR'), h('h3', null, cur.name),
        cur.batches.length ? cur.batches.map(function (b) {
          return h('button', { key: b.id, className: 'dx-row', onClick: function () { p.go('journey/' + b.id); } },
            h('strong', null, b.id + ' \u00B7 ' + b.crop + ' \u00B7 ' + b.quantity), h(Badge, { tone: tone(b) }, b.risk.toUpperCase()), h('small', null, b.stage + ' \u00B7 from ' + b.origin));
        }) : h('p', { className: 'dx-empty' }, 'No batches linked to this buyer yet.')));
  }

  /* ---------- Leaf artwork (inline SVG, works offline) ---------- */
  function LeafArt(p) {
    var leaf = function (d, vein, fill, o) { return h('g', { opacity: o || 1 }, h('path', { d: d, fill: fill, stroke: 'rgba(214,185,138,.45)', strokeWidth: 1.2 }), h('path', { d: vein, fill: 'none', stroke: 'rgba(214,185,138,.4)', strokeWidth: 1 })); };
    return h('svg', { viewBox: '0 0 520 520', className: p.className || 'leaf-art', 'aria-hidden': true },
      leaf('M260 520C170 380 180 170 330 20 440 160 430 380 260 520Z', 'M260 520C262 380 296 190 330 20M268 420l-70-44M276 350l-84-58M290 280l-80-60M308 210l-58-50M270 440l78-48M284 370l92-60M300 300l90-70M318 230l66-60', '#17422f'),
      leaf('M150 520C60 420 70 280 180 190 250 290 230 430 150 520Z', 'M150 520C146 420 160 300 180 190M152 440l-50-34M160 380l-58-40M168 320l-48-36', '#0e2a1e', .95),
      leaf('M390 520C440 440 450 340 400 250 340 330 330 440 390 520Z', 'M390 520C400 440 400 340 400 250M392 450l34-40M394 390l40-36', '#2a1f16', .95));
  }
  function Photo(p) { return h('div', { className: 'ph ' + (p.className || ''), style: { backgroundImage: 'url(' + p.src + '), linear-gradient(135deg,#1d4a35,#2a1f16)' }, role: 'img', 'aria-label': p.alt || '' }); }
  var IMG_TOMATO = 'https://images.unsplash.com/photo-1682432682898-5438b8ed6985?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=80&w=900';
  var IMG_CRATES = 'https://images.unsplash.com/photo-1758972574908-bc43ad077156?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1000';
  var IMG_FIELD = 'https://images.unsplash.com/photo-1530541835461-dedaf9cf368a?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1000';

  /* ---------- Per-screen banner: each screen gets its own composition ---------- */
  function PageBanner(p) {
    var ui = UI(), Button = ui.Button, b = p.batches, cur = p.batch || b[0] || {}, v = p.view;
    var count = function (f) { return b.filter(f).length; };
    var C = { ok: 'var(--ct-ok)', warn: 'var(--ct-warn)', bad: 'var(--ct-bad)' };
    if (v === 'journey') return h('div', { className: 'pb pb-journey' },
      h('div', { className: 'ph pb-photo', style: { backgroundImage: 'url(' + (cur.image || IMG_TOMATO) + '), linear-gradient(135deg,#1d4a35,#2a1f16)' } }),
      h('div', null, h('span', { className: 'micro' }, 'BATCH JOURNEY \u00B7 ' + (cur.origin || '') + ' \u2192 ' + (cur.destination || '')),
        h('h1', null, (cur.crop || '') + ' ', h('em', null, '#' + cur.id)),
        h('p', null, cur.stage + ' \u00B7 ' + cur.quantity + ' \u00B7 ' + (cur.grade || '') + ' \u00B7 updated ' + cur.updated + '.')),
      h('div', { className: 'pb-ring', style: { '--p': cur.progress || 0 } }, h('strong', null, (cur.progress || 0) + '%'), h('small', null, 'COMPLETE')));
    if (v === 'batches') {
      var st = [['Harvested', '#8fa07a'], ['Loaded', '#b6a86c'], ['In transit', '#d6b98a'], ['Delay detected', '#e0b04f'], ['In storage', '#c58f6a'], ['Delivered', '#6f9a7e']];
      return h('div', { className: 'pb pb-batches' }, h('div', null, h('span', { className: 'micro' }, 'BATCH TRACKING'), h('h1', null, b.length + ' batches, ', h('em', null, 'one view.')), h('p', null, 'Where every batch is right now. Filter below, or open one to follow its journey.')),
        h('div', null, h('div', { className: 'pb-seg' }, st.map(function (s) { var n = count(function (x) { return x.stage === s[0]; }); return n ? h('i', { key: s[0], style: { flex: n, background: s[1] }, title: s[0] }) : null; })),
          h('div', { className: 'pb-legend' }, st.map(function (s) { return h('span', { key: s[0], style: { '--c': s[1] } }, h('b', null, count(function (x) { return x.stage === s[0]; })), s[0]); }))));
    }
    if (v === 'risk') return h('div', { className: 'pb pb-risk' }, h('div', null, h('span', { className: 'micro' }, 'RISK MONITOR \u00B7 RULE-BASED'), h('h1', null, 'See risk ', h('em', null, 'before loss.')), h('p', null, 'Temperature, delay and humidity are checked against fixed limits for every batch.')),
      h('div', { className: 'pb-risk-nums' }, [['LOW', 'Low', C.ok], ['WATCH', 'Watch', C.warn], ['HIGH', 'High', C.bad]].map(function (r) { return h('div', { key: r[0], style: { '--c': r[2] } }, h('strong', null, count(function (x) { return x.risk === r[1]; })), h('span', null, r[0])); })));
    if (v === 'climate') return h('div', { className: 'pb pb-climate' }, h('div', null, h('span', { className: 'micro' }, 'CLIMATE CONTEXT'), h('h1', null, 'Conditions ', h('em', null, 'on the route.')), h('p', null, 'Temperature per batch against the 30\u00B0C limit (gold line).')),
      h('div', { className: 'pb-therm' }, b.map(function (x) { var t = x.temperatureVal || num(x.temperature); return h('div', { key: x.id }, h('span', null, x.id), h('div', { className: 'pb-track', style: { '--c': t > 30 ? C.bad : t > 28 ? C.warn : C.ok } }, h('i', { style: { width: Math.min(100, t / 37.5 * 100) + '%' } })), h('em', null, x.temperature)); })));
    if (v === 'buyers') { var bs = buyersWithStats(b); return h('div', { className: 'pb pb-buyers' }, h('div', null, h('span', { className: 'micro' }, 'BUYER NETWORK'), h('h1', null, 'Who is ', h('em', null, 'waiting.')), h('p', null, 'Receivers, open orders and delivery status.')),
      h('div', { className: 'pb-ledger' }, [[bs.length, 'BUYERS'], [bs.reduce(function (a, x) { return a + x.activeOrders; }, 0), 'ACTIVE ORDERS'], [bs.reduce(function (a, x) { return a + x.received; }, 0), 'RECEIVED']].map(function (x) { return h('div', { key: x[1] }, h('strong', null, x[0]), h('span', null, x[1])); }))); }
    if (v === 'traceability') return h('div', { className: 'pb pb-trace' }, h('div', null, h('span', { className: 'micro' }, 'TRACEABILITY \u00B7 FULL HISTORY'), h('div', { className: 'pb-id' }, cur.id), h('p', { style: { marginTop: 12 } }, cur.crop + ' from ' + cur.origin + ' to ' + cur.destination + '. Every handoff, timestamped.'),
      h('div', { className: 'pb-actions' }, h(Button, { onClick: function () { p.go('journey/' + cur.id); } }, 'View journey'))),
      h(LeafArt, { className: 'pb-leaf' }));
    return null;
  }

  /* ---------- Landing page ---------- */
  function Landing(p) {
    var ui = UI(), Icon = ui.Icon, Logo = ui.Logo, Button = ui.Button;
    var st = useState(true), note = st[0], setNote = st[1], st2 = useState(false), sent = st2[0], setSent = st2[1];
    var cta = function () { p.go(p.authed ? 'dashboard' : 'login'); };
    var stations = [['Farm', 'Source and field recorded'], ['Harvest', 'Batch ID issued'], ['Journey', 'Loads, delays, storage'], ['Risk', 'Heat and delay flagged'], ['Buyer', 'QR history opens']];
    var ys = [74, 34, 66, 30, 62];
    return h('div', { className: 'lp' },
      note && h('div', { className: 'lp-announce' }, h('span', null, 'NEW'), 'Risk Monitor now flags heat and delay exposure on every batch.', h('button', { onClick: function () { setNote(false); }, 'aria-label': 'Dismiss' }, '\u00D7')),
      h('header', { className: 'lp-nav' }, h(Logo, null),
        h('nav', null, [['About', 'about'], ['How It Works', 'how'], ['Features', 'features'], ['Contact', 'contact']].map(function (n) { return h('button', { key: n[1], onClick: function () { nav(n[1]); } }, n[0]); })),
        h('div', { className: 'lp-nav-actions' }, h(Button, { variant: 'secondary', showArrow: false, onClick: cta }, p.authed ? 'Dashboard' : 'Login'), h(Button, { onClick: cta }, 'Get Started'))),
      h('section', { className: 'lp-hero' },
        h('div', { className: 'lp-hero-copy' },
          h('span', { className: 'eyebrow' }, 'POST-HARVEST INTELLIGENCE'),
          h('h1', null, 'Know every harvest ', h('em', null, 'from field to buyer.')),
          h('p', null, 'CropTrace gives each batch its own identity, follows it on the road and in storage, and flags heat and delay before quality is lost.'),
          h('div', { className: 'lp-cta' }, h(Button, { onClick: cta }, 'Enter CropTrace'), h(Button, { variant: 'secondary', showArrow: false, onClick: function () { nav('how'); } }, 'How it works'))),
        h('div', { className: 'lp-art' },
          h(LeafArt, null),
          h('div', { className: 'lp-chip lp-chip-batch' }, h(Photo, { src: IMG_TOMATO, className: 'lp-chip-img' }), h('div', null, h('small', null, 'BATCH'), h('strong', null, 'CT-2841 \u00B7 Tomato'), h('div', { className: 'lp-bar' }, h('i', { style: { width: '68%' } })), h('small', null, 'In transit \u00B7 68% to Delhi NCR'))),
          h('div', { className: 'lp-chip lp-chip-risk' }, h('small', null, 'RISK'), h('strong', null, 'Low'), h('span', { className: 'dot ok' })),
          h('div', { className: 'lp-chip lp-chip-temp' }, h('small', null, 'TEMPERATURE'), h('strong', null, '27\u00B0C')))),
      h('section', { className: 'lp-story' },
        h('svg', { viewBox: '0 0 1000 140', preserveAspectRatio: 'none', className: 'lp-path', 'aria-hidden': true },
          h('path', { d: 'M100 ' + ys[0] * 1.4 + ' C 200 ' + ys[0] * 1.4 + ', 200 ' + ys[1] * 1.4 + ', 300 ' + ys[1] * 1.4 + ' S 400 ' + ys[2] * 1.4 + ', 500 ' + ys[2] * 1.4 + ' S 600 ' + ys[3] * 1.4 + ', 700 ' + ys[3] * 1.4 + ' S 800 ' + ys[4] * 1.4 + ', 900 ' + ys[4] * 1.4, fill: 'none', stroke: 'rgba(214,185,138,.55)', strokeWidth: 2, strokeDasharray: '2 7', strokeLinecap: 'round' })),
        h('div', { className: 'lp-stations' }, stations.map(function (s, i) { return h('div', { key: s[0], className: 'lp-station', style: { '--y': ys[i] + '%' } }, h('span', { className: 'lp-dot' }, i + 1), h('strong', null, s[0]), h('small', null, s[1])); }))),
      h('section', { className: 'lp-section', id: 'about' },
        h('div', { className: 'lp-split' }, h('div', null, h('span', { className: 'eyebrow' }, 'ABOUT'), h('h2', null, 'Built for the part of the chain ', h('em', null, 'nobody can see.'))),
          h('p', null, 'Between the field and the buyer, produce passes through trucks, mandis and storage sheds. Delays and heat quietly eat into quality, and nobody holds a shared record. CropTrace gives farmers and buyers one verifiable record per batch.'))),
      h('section', { className: 'lp-section', id: 'features' },
        h('span', { className: 'eyebrow' }, 'FEATURES'), h('h2', null, 'One workspace, ', h('em', null, 'six views.')),
        h('div', { className: 'lp-duo' },
          h('div', { className: 'lp-panel lp-panel-green' }, h('span', { className: 'micro' }, 'BATCH JOURNEY'), h('h3', null, 'Follow a batch stage by stage.'),
            h('div', { className: 'lp-mini-tl' }, ['Harvested', 'Loaded', 'In transit', 'Stored', 'Buyer'].map(function (x, i) { return h('div', { key: x, className: i < 3 ? 'on' : '' }, h('i', null), h('span', null, x)); }))),
          h('div', { className: 'lp-panel lp-panel-brown' }, h('span', { className: 'micro' }, 'RISK MONITOR'), h('h3', null, 'Low, Watch or High, with a reason.'),
            h('div', { className: 'lp-mini-risk' }, [['CT-2843', 'High', 'Temperature above range', 'bad'], ['CT-2842', 'Watch', 'Transit delay detected', 'warn'], ['CT-2841', 'Low', 'Within range', 'ok']].map(function (r) { return h('div', { key: r[0] }, h('span', { className: 'dot ' + r[3] }), h('strong', null, r[0]), h('small', null, r[2]), h('em', null, r[1])); })))),
        h('div', { className: 'lp-tiles' }, [['database', 'Batches', 'Every batch, one list'], ['weather', 'Climate Context', 'Conditions on the route'], ['user', 'Buyers', 'Who is receiving what'], ['scan', 'Traceability', 'Full history and QR']].map(function (x) { return h('div', { key: x[1], className: 'lp-tile' }, h(Icon, { name: x[0], size: 20 }), h('strong', null, x[1]), h('small', null, x[2])); }))),
      h('section', { className: 'lp-section lp-how', id: 'how' },
        h('div', null, h('span', { className: 'eyebrow' }, 'HOW IT WORKS'), h('h2', null, 'From harvest ', h('em', null, 'to handoff.')),
          h('ol', { className: 'lp-steps' }, [['Create a batch', 'Crop, quantity, harvest time, origin and destination.'], ['Track the journey', 'Log loading, transport, delays and storage.'], ['Assess risk', 'Time, temperature and humidity become a simple signal.'], ['Share with buyers', 'A QR code opens the verified batch history.']].map(function (x, i) { return h('li', { key: x[0] }, h('span', null, '0' + (i + 1)), h('div', null, h('strong', null, x[0]), h('small', null, x[1]))); }))),
        h('div', { className: 'lp-how-art' }, h(Photo, { src: IMG_CRATES, className: 'lp-how-photo' }), h(Photo, { src: IMG_FIELD, className: 'lp-how-photo2' }))),
      h('section', { className: 'lp-section lp-trust' },
        h('div', { className: 'lp-trust-grid' }, [['1', 'identity per batch'], ['5', 'journey stages tracked'], ['3', 'clear risk levels'], ['QR', 'buyer verification']].map(function (x) { return h('div', { key: x[1] }, h('strong', null, x[0]), h('span', null, x[1])); })),
        h('p', null, 'Designed for farmers, mandis and buyers who need the same answer to the same question: where is this batch, and is it still in good condition?')),
      h('section', { className: 'lp-section lp-contact', id: 'contact' },
        h('div', null, h('span', { className: 'eyebrow' }, 'CONTACT'), h('h2', null, 'Talk to the ', h('em', null, 'CropTrace team.')), h('p', null, 'Want a walkthrough or have a question? Leave a note.'), h('div', { className: 'lp-cta' }, h(Button, { onClick: cta }, 'Enter CropTrace'))),
        sent ? h('div', { className: 'lp-form lp-sent' }, h(Icon, { name: 'check', size: 20 }), h('strong', null, 'Thanks, we\u2019ve got your message.'), h('small', null, 'We\u2019ll be in touch soon.'))
          : h('form', { className: 'lp-form', onSubmit: function (e) { e.preventDefault(); setSent(true); } }, h('input', { placeholder: 'Your name', required: true }), h('input', { type: 'email', placeholder: 'Email', required: true }), h('textarea', { placeholder: 'How can we help?', rows: 3, required: true }), h('button', { className: 'button button-primary', type: 'submit' }, 'Send message'))),
      h('footer', { className: 'lp-footer' }, h(Logo, null), h('span', null, '\u00A9 2026 CROPTRACE. Making the post-harvest journey more visible.')));
  }

  /* ---------- Login page (demo only: no real authentication) ---------- */
  function Login(p) {
    var ui = UI(), Logo = ui.Logo, Button = ui.Button, Icon = ui.Icon;
    var a = useState(''), email = a[0], setEmail = a[1], b = useState(''), pw = b[0], setPw = b[1];
    var c = useState(true), remember = c[0], setRemember = c[1], d = useState(''), msg = d[0], setMsg = d[1];
    function submit(e) { e.preventDefault(); if (!email.trim() || pw.length < 4) { setMsg('Enter an email or username and a password to continue.'); return; } p.onLogin(email.trim(), remember); }
    return h('div', { className: 'auth' },
      h('aside', { className: 'auth-side' }, h(LeafArt, { className: 'auth-leaf' }), h(Logo, null),
        h('div', { className: 'auth-copy' }, h('h2', null, 'Track every harvest. ', h('em', null, 'Protect every batch.')),
          h('p', null, 'Sign in to your Farm Operations workspace to follow batches, watch risk and share verified journeys with buyers.')),
        h('button', { className: 'auth-back', onClick: function () { p.go(''); } }, '\u2190 Back to home')),
      h('main', { className: 'auth-main' }, h('form', { className: 'auth-card', onSubmit: submit },
        h('span', { className: 'micro' }, 'WELCOME BACK'), h('h1', null, 'Log in'),
        h('label', null, 'Email or username', h('input', { value: email, onChange: function (e) { setEmail(e.target.value); setMsg(''); }, placeholder: 'you@farm.example', autoComplete: 'username' })),
        h('label', null, 'Password', h('input', { type: 'password', value: pw, onChange: function (e) { setPw(e.target.value); setMsg(''); }, placeholder: 'Password', autoComplete: 'current-password' })),
        h('div', { className: 'auth-row' }, h('label', { className: 'auth-check' }, h('input', { type: 'checkbox', checked: remember, onChange: function (e) { setRemember(e.target.checked); } }), 'Remember me'),
          h('button', { type: 'button', className: 'dx-link', onClick: function () { setMsg('Please contact your administrator to reset your password.'); } }, 'Forgot password?')),
        msg && h('p', { className: 'auth-msg' }, msg),
        h(Button, { type: 'submit' }, 'Log in'), h('div', { className: 'auth-or' }, 'or'),
        h(Button, { variant: 'secondary', showArrow: false, onClick: function () { p.onLogin('demo@croptrace.app', remember); } }, 'Continue as guest'),
        h('small', { className: 'auth-note' }, h(Icon, { name: 'shield', size: 13 }), ' Your workspace is stored in this browser.'))));
  }

  window.CropTraceViews = { Landing: Landing, Login: Login, BatchPicker: BatchPicker, DashboardExtras: DashboardExtras,
    RiskBoard: RiskBoard, ClimateBoard: ClimateBoard, BuyersView: BuyersView, climateFor: climateFor, buyersWithStats: buyersWithStats, PageBanner: PageBanner, riskReasons: riskReasons };
})();
