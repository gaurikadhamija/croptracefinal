/* CropTrace local data layer.
   Replaces: Express backend + Firebase/Firestore + Gemini calls.
   Same method names/return shapes as the old frontend/src/services/api.ts,
   but data lives in localStorage (seeded from data/data.js). Works from file://. */
(function () {
  var KEY = 'croptrace_db_v2';
  var D = window.CROPTRACE_DATA || {};
  var mem = null; // fallback if localStorage is blocked

  function clone(x) { return JSON.parse(JSON.stringify(x)); }
  function emptyDb() {
    return { crop_batches: [], traceability_events: [], iot_devices: [], sensor_readings: [], farms: [], crops: [], notifications: [] };
  }
  function seedInto(db) {
    var count = 0;
    function put(col, item) {
      var i = db[col].findIndex(function (x) { return x.id === item.id; });
      if (i >= 0) db[col][i] = clone(item); else db[col].push(clone(item));
      count++;
    }
    (D.DEMO_FARMS || []).forEach(function (x) { put('farms', x); });
    (D.DEMO_BATCHES || []).forEach(function (x) { put('crop_batches', x); });
    (D.DEMO_EVENTS || []).forEach(function (x) { put('traceability_events', x); });
    if (D.DEMO_IOT_DEVICE) put('iot_devices', D.DEMO_IOT_DEVICE);
    (D.DEMO_NOTIFICATIONS || []).forEach(function (x) { put('notifications', x); });
    var base = Date.now(), temps = [26.8, 27.0, 27.2, 27.4, 27.5, 27.3, 27.4], hums = [65, 66, 67, 68, 68, 69, 68];
    for (var i = 0; i < temps.length; i++) {
      var rid = 'read-demo-' + (i + 1);
      put('sensor_readings', { id: rid, readingId: rid, deviceId: 'ESP32-001', farmId: 'farm-haryana-01', batchId: 'CT-2841',
        temperature: temps[i], humidity: hums[i], soilMoisture: 48.0, motionShock: 0.12,
        timestamp: new Date(base - (6 - i) * 600000).toISOString(), isSimulated: true });
    }
    return count;
  }
  function load() {
    var raw = null;
    try { raw = localStorage.getItem(KEY); } catch (e) {}
    if (!raw && mem) raw = mem;
    if (raw) { try { return JSON.parse(raw); } catch (e) {} }
    var db = emptyDb(); seedInto(db); save(db); return db; // first run: auto-seed demo data
  }
  function save(db) {
    var s = JSON.stringify(db); mem = s;
    try { localStorage.setItem(KEY, s); } catch (e) {}
  }
  function hhmm() { return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); }
  function ts(x) { return new Date(x || 0).getTime(); }
  function fail(msg) { return Promise.reject(new Error(msg)); }
  function ok(v) { return Promise.resolve(clone(v)); }

  var CROP_IMAGES = {
    Tomato: 'https://images.unsplash.com/photo-1682432682898-5438b8ed6985?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=80&w=300',
    Potato: 'https://images.unsplash.com/photo-1759406594127-ce54cb67fb53?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=80&w=300',
    Onion: 'https://images.unsplash.com/photo-1635628666885-e6b11e643ed4?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=80&w=300'
  };
  var PROGRESS = { Harvested: 20, Loaded: 40, 'In transit': 65, 'Delay detected': 50, 'In storage': 85, Delivered: 100 };

  window.CropTraceAPI = {
    getDashboard: function () {
      var db = load(), b = db.crop_batches;
      var s = { totalBatches: b.length, activeBatches: 0, atRiskBatches: 0, inTransitBatches: 0, storedBatches: 0,
        totalFarms: db.farms.length, iotDevicesOnline: db.iot_devices.length, latestTemperature: '27.4°C', latestHumidity: '68%',
        lastSyncTime: hhmm(), isDbEmpty: b.length === 0 };
      b.forEach(function (x) {
        if (x.stage !== 'Delivered') s.activeBatches++;
        if (x.risk === 'Watch' || x.risk === 'High') s.atRiskBatches++;
        if (x.stage === 'In transit' || x.stage === 'Loaded' || x.stage === 'Delay detected') s.inTransitBatches++;
        if (x.stage === 'In storage') s.storedBatches++;
      });
      if (!s.activeBatches && !s.isDbEmpty) s.activeBatches = b.length;
      var r = db.sensor_readings.slice().sort(function (a, c) { return ts(c.timestamp) - ts(a.timestamp); })[0];
      if (r) {
        if (typeof r.temperature === 'number') s.latestTemperature = r.temperature.toFixed(1) + '°C';
        if (typeof r.humidity === 'number') s.latestHumidity = r.humidity.toFixed(0) + '%';
      }
      return ok(s);
    },
    getBatches: function (q, crop, risk) {
      var list = load().crop_batches.slice();
      if (q) { var ql = String(q).toLowerCase(); list = list.filter(function (b) {
        return [b.batchNumber, b.id, b.crop, b.origin, b.destination].some(function (v) { return v && String(v).toLowerCase().indexOf(ql) >= 0; }); }); }
      if (crop && crop !== 'All crops') list = list.filter(function (b) { return b.crop && b.crop.toLowerCase() === crop.toLowerCase(); });
      if (risk && risk !== 'All risk levels') list = list.filter(function (b) { return b.risk && b.risk.toLowerCase() === risk.toLowerCase(); });
      list.sort(function (a, c) { return ts(c.createdAt) - ts(a.createdAt); });
      return ok(list);
    },
    getBatchById: function (id) {
      var b = load().crop_batches.find(function (x) { return x.id === id; });
      return b ? ok(b) : fail('Batch not found');
    },
    createBatch: function (d) {
      if (!d || !d.crop || !d.quantity || !d.origin || !d.destination)
        return fail('Crop, quantity, origin, and destination are required fields.');
      var db = load(), id, nowIso = new Date().toISOString();
      do { id = 'CT-' + Math.floor(2800 + Math.random() * 200); } while (db.crop_batches.some(function (x) { return x.id === id; }));
      var b = { id: id, batchId: id, batchNumber: id, crop: String(d.crop), variety: d.variety || d.crop + ' Standard Variety',
        quantity: String(d.quantity), origin: String(d.origin), destination: String(d.destination), harvestDate: d.harvestDate || nowIso,
        grade: d.grade || 'Grade A', stage: 'Harvested', progress: 15, temperature: '26°C', temperatureVal: 26.0, humidity: '65%',
        delay: '0 hrs', risk: 'Low', riskScore: 20, image: CROP_IMAGES[d.crop] || CROP_IMAGES.Tomato, updated: 'Just now',
        recommendedAction: 'Keep in ventilated holding area pending transport load.', actionTaken: false, isDemo: false,
        createdAt: nowIso, updatedAt: nowIso };
      db.crop_batches.push(b);
      var eid = 'evt-' + id + '-1';
      db.traceability_events.push({ id: eid, eventId: eid, batchId: id, stage: 'Harvested', time: hhmm(), timestamp: nowIso, risk: 'LOW', tone: 'low',
        location: d.origin + ' Farm Hub', actor: 'CropTrace Field Operator',
        notes: 'Freshly harvested ' + d.crop + '. Batch ' + id + ' initialized with ' + d.quantity + '.', temperature: '26°C', humidity: '65%', createdAt: nowIso });
      save(db); return ok(b);
    },
    updateBatch: function (id, updates) {
      var db = load(), i = db.crop_batches.findIndex(function (x) { return x.id === id; });
      if (i < 0) return fail('Batch not found');
      db.crop_batches[i] = Object.assign({}, db.crop_batches[i], updates, { updatedAt: new Date().toISOString(), updated: 'Just now' });
      save(db); return ok(db.crop_batches[i]);
    },
    getTraceability: function (batchId) {
      var list = load().traceability_events.filter(function (e) { return e.batchId === batchId; });
      list.sort(function (a, c) { return ts(a.timestamp || a.createdAt) - ts(c.timestamp || c.createdAt); });
      return ok(list);
    },
    getAllTraceability: function () {
      var list = load().traceability_events.slice();
      list.sort(function (a, c) { return ts(c.timestamp || c.createdAt) - ts(a.timestamp || a.createdAt); });
      return ok(list);
    },
    createTraceabilityEvent: function (e) {
      if (!e || !e.batchId || !e.stage) return fail('batchId and stage are required for traceability events.');
      var db = load(), nowIso = new Date().toISOString(), id = 'evt-' + Date.now();
      var ev = { id: id, eventId: id, batchId: e.batchId, stage: e.stage, time: hhmm(), timestamp: nowIso, location: e.location || 'Transit Node',
        actor: e.actor || 'Supply Chain Operator', notes: e.notes || 'Recorded ' + e.stage + ' event for batch ' + e.batchId,
        risk: e.risk || 'LOW', tone: e.tone || 'low', temperature: e.temperature || '27°C', humidity: e.humidity || '68%', createdAt: nowIso };
      db.traceability_events.push(ev);
      var b = db.crop_batches.find(function (x) { return x.id === e.batchId; });
      if (b) { b.stage = e.stage; b.progress = PROGRESS[e.stage] || b.progress || 50; b.updated = 'Just now'; b.updatedAt = nowIso; }
      save(db); return ok(ev);
    },
    getIoTDevices: function () { return ok(load().iot_devices); },
    getSensorReadings: function (batchId, limitCount) {
      var max = Math.min(Number(limitCount) || 40, 100), list = load().sensor_readings.slice();
      if (batchId) list = list.filter(function (r) { return r.batchId === batchId; });
      list.sort(function (a, c) { return ts(a.timestamp) - ts(c.timestamp); });
      return ok(list.slice(-max));
    },
    postSensorReading: function (r) {
      if (!r || !r.deviceId) return fail('deviceId is required');
      var t = Number(r.temperature), h = Number(r.humidity);
      if (isNaN(t) || t < -30 || t > 80) return fail('temperature must be a valid numeric degree Celsius between -30°C and 80°C');
      if (isNaN(h) || h < 0 || h > 100) return fail('humidity must be a valid percentage between 0% and 100%');
      var db = load(), id = 'read-' + Date.now(), when = r.timestamp ? new Date(r.timestamp).toISOString() : new Date().toISOString();
      var rec = { id: id, readingId: id, deviceId: String(r.deviceId), farmId: r.farmId ? String(r.farmId) : 'farm-haryana-01',
        batchId: r.batchId ? String(r.batchId) : 'CT-2841', temperature: Number(t.toFixed(1)), humidity: Number(h.toFixed(1)),
        soilMoisture: r.soilMoisture ? Number(r.soilMoisture) : 48.0, motionShock: r.motionShock ? Number(r.motionShock) : 0.12,
        timestamp: when, isSimulated: r.isSimulated !== undefined ? Boolean(r.isSimulated) : false };
      db.sensor_readings.push(rec);
      var dev = db.iot_devices.find(function (x) { return x.id === rec.deviceId; });
      var patch = { id: rec.deviceId, deviceId: rec.deviceId, deviceName: 'ESP32 Node (' + rec.deviceId + ')', deviceType: 'ESP32-WROOM-32D',
        status: 'online', lastSeen: when, isSimulated: Boolean(r.isSimulated) };
      if (dev) Object.assign(dev, patch); else db.iot_devices.push(Object.assign({ createdAt: when }, patch));
      var batchUpdated = false;
      if (r.batchId) {
        var b = db.crop_batches.find(function (x) { return x.id === String(r.batchId); });
        if (b) {
          var risk, score = b.riskScore || 25;
          if (t >= 32) { risk = 'High'; score = Math.max(score, 75); }
          else if (t >= 29) { risk = 'Watch'; score = Math.max(score, 58); }
          else { risk = 'Low'; score = Math.min(score, 30); }
          Object.assign(b, { temperature: t.toFixed(1) + '°C', temperatureVal: t, humidity: h.toFixed(0) + '%', risk: risk, riskScore: score, updated: 'Just now', updatedAt: when });
          batchUpdated = true;
        }
      }
      save(db); return ok({ success: true, reading: rec, batchUpdated: batchUpdated });
    },
    getFarms: function () { return ok(load().farms); },
    createFarm: function (f) {
      if (!f || !f.farmName || !f.location) return fail('farmName and location are required');
      var db = load(), id = 'farm-' + Date.now();
      var farm = { id: id, farmId: id, farmName: f.farmName, location: f.location, crops: f.crops || ['Tomato', 'Potato'], createdAt: new Date().toISOString() };
      db.farms.push(farm); save(db); return ok(farm);
    },
    getCrops: function () { return ok(load().crops); },
    getNotifications: function () {
      var l = load().notifications.slice(); l.sort(function (a, c) { return ts(c.createdAt) - ts(a.createdAt); }); return ok(l);
    },
    markNotificationRead: function (id) {
      var db = load(), n = db.notifications.find(function (x) { return x.id === id; });
      if (n) { n.read = true; save(db); }
      return ok({ success: true });
    },
    seedDemoData: function () {
      var db = load(), count = seedInto(db); save(db);
      return ok({ success: true, message: 'Demo CropTrace datasets loaded into local storage successfully.', count: count });
    },
    /* Offline rule-based insights (replaces the Gemini call; same fallback logic as the old backend). */
    getAiInsights: function (batch) {
      if (!batch || !batch.crop) return fail('Batch object with crop is required');
      var temp = batch.temperature || '27°C', delay = batch.delay || '0 hrs', crop = batch.crop;
      var hot = parseFloat(temp) > 30, delayed = delay !== '0 hrs';
      var a = 'Batch ' + (batch.batchNumber || batch.id) + ' (' + crop + ') is currently maintaining stable holding conditions.';
      if (hot) a = 'Elevated thermal exposure (' + temp + ') accelerates ' + crop + ' enzymatic respiration and pulp softening during transit.';
      else if (delayed) a = 'Transit delay of ' + delay + ' increases post-harvest moisture evaporation without active refrigeration.';
      return ok({ riskAnalysis: a,
        shelfLifeImpact: hot ? 'Shelf-life reduced by approx 18-24 hours if unshaded.' : 'Normal expected shelf life maintained.',
        handlingRecommendation: hot ? 'Move crates to shaded holding bay, ensure unobstructed cross-ventilation, and prioritize immediate buyer handoff.'
          : 'Maintain steady route transit speed and avoid prolonged stationary stops under direct sunlight.',
        temperatureRiskLevel: hot ? 'Elevated' : delayed ? 'Watch' : 'Low', isAiGenerated: false });
    },
    resetLocalData: function () { try { localStorage.removeItem(KEY); } catch (e) {} mem = null; }
  };

  // Offline-friendly: if a remote photo can't load, fall back to the bundled local image.
  document.addEventListener('error', function (e) {
    var t = e.target;
    if (t && t.tagName === 'IMG' && !t.dataset.fallback) { t.dataset.fallback = '1'; t.src = 'assets/images/leaf-reference.png'; }
  }, true);
})();
