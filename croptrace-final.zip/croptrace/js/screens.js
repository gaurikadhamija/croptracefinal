/* CropTrace application screens. Loaded after views.js, before app.js. */
(function () {
  var React = window.React, h = React.createElement, useState = React.useState;
  var V = window.CropTraceViews;
  function UI() { return window.CropTraceUI; }
  function num(s) { var m = String(s == null ? '' : s).match(/-?\d+(\.\d+)?/); return m ? parseFloat(m[0]) : 0; }
  function tone(b) { return String(b.risk || 'Low').toLowerCase(); }
  var STAGES = ['Harvested', 'Loaded', 'In Transit', 'Storage', 'Buyer'];
  function stageIdx(s) {
    s = String(s || '').toLowerCase();
    if (s.indexOf('harvest') >= 0) return 0; if (s.indexOf('load') >= 0) return 1;
    if (s.indexOf('transit') >= 0 || s.indexOf('delay') >= 0) return 2;
    if (s.indexOf('stor') >= 0) return 3; if (s.indexOf('deliver') >= 0 || s.indexOf('buyer') >= 0) return 4; return 0;
  }
  function fmtDate(iso) { try { var d = new Date(iso); if (isNaN(d)) return ''; return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' }) + ' \u00B7 ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }); } catch (e) { return ''; } }
  function evtWhen(e) { return e.timestamp ? fmtDate(e.timestamp) : (e.time || ''); }

  /* ---------- small inline icons ---------- */
  var P = {
    pin: 'M10 18s6-5.2 6-10a6 6 0 1 0-12 0c0 4.8 6 10 6 10Zm0-7.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z',
    drop: 'M10 2.5s5 5.2 5 8.8a5 5 0 0 1-10 0C5 7.700 10 2.500 10 2.500Z',
    therm: 'M8 12.500V5a2 2 0 1 1 4 0v7.500a3.500 3.500 0 1 1-4 0ZM10 8v6',
    clock: 'M10 3a7 7 0 1 0 0 14 7 7 0 0 0 0-14Zm0 3.500V10l3 2',
    sun: 'M10 6.500a3.500 3.500 0 1 0 0 7 3.500 3.500 0 0 0 0-7ZM10 1.500v2M10 16.500v2M1.500 10h2M16.500 10h2M4 4l1.400 1.400M14.600 14.600 16 16M16 4l-1.400 1.400M5.400 14.600 4 16',
    cloud: 'M5.500 15.500h9a3 3 0 0 0 .2-6 5 5 0 0 0-9.500-1.300 3.700 3.700 0 0 0 .3 7.300Z',
    rain: 'M5.500 12.500h9a3 3 0 0 0 .2-6 5 5 0 0 0-9.500-1.300 3.700 3.700 0 0 0 .3 7.300ZM7 15l-1 2.500M10.500 15l-1 2.500M14 15l-1 2.500',
    sprout: 'M10 17V9M10 11c-4 0-6-2-6-5 4 0 6 2 6 5ZM10 13c3.500 0 5.500-1.700 5.500-4.500-3.500 0-5.500 1.700-5.500 4.500Z',
    box: 'm3 6 7-3 7 3-7 3-7-3Zm0 0v8l7 3 7-3V6M10 9v8',
    truck: 'M2 5h10v8H2zM12 8h3.500l2.500 3v2h-6M5.500 15.500a1.500 1.500 0 1 0 0-3 1.500 1.500 0 0 0 0 3ZM14.500 15.500a1.500 1.500 0 1 0 0-3 1.500 1.500 0 0 0 0 3Z',
    store: 'M3 8l1.500-5h11L17 8M3 8v9h14V8M3 8h14M8 17v-5h4v5',
    hand: 'm3 10 4-3 3 1 3-1 4 3M3 10l4 5 2 .500M17 10l-3 5-3 1.500-3-1',
    warn: 'M10 2.500 18 16H2L10 2.500ZM10 8v4M10 14v.100',
    shield: 'M10 2.500 17 5v5c0 4.200-2.800 6.600-7 8-4.200-1.400-7-3.800-7-8V5l7-2.500ZM7 10l2 2 4-4',
    arrow: 'M4 10h12M12 6l4 4-4 4', scan: 'M7 3H3v4M13 3h4v4M7 17H3v-4M13 17h4v-4M7 7h6v6H7z', check: 'm4 10 4 4 8-9', user: 'M10 10a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM4 17c.500-3.300 2.500-5 6-5s5.500 1.700 6 5'
  };
  function Ic(p) { return h('svg', { width: p.size || 16, height: p.size || 16, viewBox: '0 0 20 20', fill: 'none', stroke: 'currentColor', strokeWidth: 1.5, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true, className: p.className }, h('path', { d: P[p.n] || P.pin })); }
  function weatherIcon(w) { w = String(w || '').toLowerCase(); return /rain|storm|shower/.test(w) ? 'rain' : /cloud|haz/.test(w) ? 'cloud' : 'sun'; }
  var STAGE_ICON = ['sprout', 'box', 'truck', 'store', 'hand'];

  /* ---------- rule-based assessment ---------- */
  function assess(b) {
    var t = b.temperatureVal || num(b.temperature), d = num(b.delay), hum = num(b.humidity);
    var why = [];
    if (t > 30 && d >= 1) why.push('Extended temperature exposure combined with a ' + d + ' hr delay may affect the batch during transit.');
    else if (t > 30) why.push('Temperature is above the 30\u00B0C recommended limit and may shorten shelf life.');
    else if (d >= 1) why.push('A ' + d + ' hr delay extends time without active cooling.');
    if (hum > 70) why.push('High humidity raises the chance of moisture and decay problems.');
    if (!why.length) why.push('Temperature, delay and humidity are all within the recommended range.');
    var action = b.recommendedAction || (b.risk === 'High' ? 'Prioritize dispatch and move to shaded or cooler holding.' : b.risk === 'Watch' ? 'Shade, ventilate and prioritize handling.' : 'Continue as planned.');
    return { t: t, d: d, hum: hum, why: why, action: action, tState: t >= 32 ? 'bad' : t > 30 ? 'warn' : 'ok', hState: hum > 75 ? 'bad' : hum > 70 ? 'warn' : 'ok', dState: d >= 3 ? 'bad' : d >= 1 ? 'warn' : 'ok' };
  }
  function seed(id) { var n = 0; String(id).split('').forEach(function (c) { n = (n * 31 + c.charCodeAt(0)) % 9973; }); return n; }
  function series(b, n) { // recent temperature trend ending at the current reading
    var t = b.temperatureVal || num(b.temperature), s = seed(b.id), out = [], hot = t > 29;
    for (var i = 0; i < n; i++) { var k = (n - 1 - i) / (n - 1); out.push(t - (hot ? 3.2 : 1.4) * k + Math.sin(s + i * 1.7) * 0.5); }
    out[n - 1] = t; return out;
  }
  function Spark(p) {
    var w = p.w || 120, ht = p.h || 36, pts = series(p.batch, 12), mn = Math.min.apply(null, pts.concat([27])), mx = Math.max.apply(null, pts.concat([31]));
    var X = function (i) { return (i / 11) * w; }, Y = function (v) { return ht - 3 - ((v - mn) / (mx - mn || 1)) * (ht - 6); };
    var d = pts.map(function (v, i) { return (i ? 'L' : 'M') + X(i).toFixed(1) + ' ' + Y(v).toFixed(1); }).join(' ');
    return h('svg', { className: 'spark spark-' + (p.state || 'ok'), viewBox: '0 0 ' + w + ' ' + ht, width: '100%', height: ht, preserveAspectRatio: 'none', role: 'img', 'aria-label': 'Temperature trend' },
      h('line', { x1: 0, x2: w, y1: Y(30), y2: Y(30), className: 'spark-limit' }), h('path', { d: d + ' L' + w + ' ' + ht + ' L0 ' + ht + 'Z', className: 'spark-area' }), h('path', { d: d, className: 'spark-line' }), h('circle', { cx: X(11), cy: Y(pts[11]), r: 2.800, className: 'spark-dot' }));
  }
  function Meter(p) { // horizontal gauge with limit mark
    var pct = Math.max(4, Math.min(100, ((p.v - p.min) / (p.max - p.min)) * 100)), lim = p.limit != null ? ((p.limit - p.min) / (p.max - p.min)) * 100 : null;
    return h('div', { className: 'meter2 m-' + p.state }, h('i', { style: { width: pct + '%' } }), lim != null && h('b', { style: { left: lim + '%' } }));
  }
  function Severity(p) { var lv = { Low: 1, Watch: 2, High: 3 }[p.risk] || 1; return h('div', { className: 'sev sev-' + String(p.risk).toLowerCase() }, [1, 2, 3].map(function (i) { return h('i', { key: i, className: i <= lv ? 'on' : '' }); }), h('span', null, p.risk === 'High' ? 'Severe' : p.risk === 'Watch' ? 'Elevated' : 'Normal')); }
  function Empty(p) { return h('div', { className: 'empty-state' }, h('span', null, h(UI().Icon, { name: p.icon || 'leaf', size: 22 })), h('strong', null, p.title), h('p', null, p.text), p.action); }
  function Loading(p) { return h('div', { className: 'loading-state', role: 'status', 'aria-live': 'polite' }, [0, 1, 2].map(function (i) { return h('i', { key: i }); }), h('span', null, p.text || 'Loading\u2026')); }
  function Head(p) { return UI().WorkspaceHeading(p); }
  function Thumb(p) { return h('span', { className: 'thumb ph', style: { backgroundImage: 'url(' + (p.b.image || '') + '), linear-gradient(135deg,#1d4a35,#2a1f16)' }, role: 'img', 'aria-label': p.b.crop }); }
  function RiskPill(p) { return h('span', { className: 'rpill rpill-' + tone(p.b) }, h('i', null), p.b.risk + ' risk'); }

  /* ---------- ATTENTION CARD: the main alert component ---------- */
  function AlertCard(p) {
    var ui = UI(), b = p.batch, a = assess(b), Button = ui.Button;
    return h('article', { className: 'alert alert-' + tone(b) },
      h('div', { className: 'alert-top' },
        h('span', { className: 'alert-flag' }, h('i', null), h(Ic, { n: 'warn', size: 14 }), b.risk + ' risk'),
        h('div', { className: 'alert-id' }, h('strong', null, 'Batch ' + b.id), h('small', null, b.crop + ' \u00B7 ' + b.origin + ' \u2192 ' + b.destination)),
        h(Severity, { risk: b.risk })),
      h('div', { className: 'alert-read' },
        h('div', { className: 'rd rd-' + a.tState }, h(Ic, { n: 'therm', size: 18 }), h('strong', null, a.t.toFixed(1) + '\u00B0C'), h('small', null, 'Temperature')),
        h('div', { className: 'rd rd-' + a.dState }, h(Ic, { n: 'clock', size: 18 }), h('strong', null, a.d >= 1 ? '+' + a.d + ' hr' : 'On time'), h('small', null, 'Delay')),
        h('div', { className: 'rd rd-' + a.hState }, h(Ic, { n: 'drop', size: 18 }), h('strong', null, a.hum + '%'), h('small', null, a.hState === 'ok' ? 'Humidity' : 'High humidity'))),
      h('div', { className: 'alert-cols' },
        h('div', null, h('span', { className: 'micro' }, 'WHY IT MATTERS'), h('p', null, a.why.join(' '))),
        h('div', null, h('span', { className: 'micro' }, 'RECOMMENDED ACTION'), h('p', { className: 'alert-act' }, a.action))),
      h('div', { className: 'alert-btns' },
        h(Button, { variant: 'secondary', showArrow: false, onClick: function () { p.go('journey/' + b.id); } }, 'View journey'),
        b.actionTaken ? h('span', { className: 'alert-done' }, h(Ic, { n: 'check', size: 14 }), ' Action recorded') : h(Button, { showArrow: false, disabled: p.acting, onClick: function () { p.onAction(b.id); } }, p.acting ? 'Saving\u2026' : 'Take action')));
  }

  /* ---------- journey mini visuals ---------- */
  function MiniJourney(p) {
    var cur = stageIdx(p.b.stage), pct = Math.min(100, (cur + (p.b.progress % 25 > 0 ? 0.5 : 0)) / 4 * 100);
    return h('div', { className: 'mj mj-' + tone(p.b) }, h('div', { className: 'mj-line' }, h('i', { style: { width: pct + '%' } }), h('span', { style: { left: pct + '%' } })), h('div', { className: 'mj-dots' }, STAGES.map(function (s, i) { return h('b', { key: s, className: i < cur ? 'done' : i === cur ? 'now' : '', title: s }); })));
  }

  /* ---------- DASHBOARD ---------- */
  function Dashboard(p) {
    var ui = UI(), b = p.batches, Button = ui.Button, d = new Date();
    var risky = b.filter(function (x) { return x.risk === 'High' || x.risk === 'Watch'; }).sort(function (x, y) { return (y.riskScore || 0) - (x.riskScore || 0); });
    var active = b.filter(function (x) { return x.stage !== 'Delivered'; });
    var st = p.stats || {}, moving = b.filter(function (x) { return /transit|loaded|delay/i.test(x.stage); }).length;
    var kg = active.reduce(function (a, x) { return a + (x.quantityKg || num(x.quantity)); }, 0);
    var metrics = [['Active batches', st.activeBatches != null ? st.activeBatches : active.length, kg + ' kg in the chain', 'box', 'batches'], ['Needs attention', risky.length, risky.length ? 'Action recommended' : 'All clear', 'warn', 'risk'], ['In transit', moving, 'Moving to buyers', 'truck', 'journey/' + p.selectedId], ['In storage', b.filter(function (x) { return /stor/i.test(x.stage); }).length, 'Awaiting buyer', 'store', 'batches']];
    var hello = d.getHours() < 12 ? 'Good morning' : d.getHours() < 17 ? 'Good afternoon' : 'Good evening';
    return h('section', { className: 'workspace-section dash', id: 'dashboard', 'data-dashboard-section': true },
      h('div', { className: 'dash-head' }, h('div', null, h('span', { className: 'date-label' }, d.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).toUpperCase()), h('h1', null, hello), h('p', null, 'Here is where your harvests stand today.')), h('div', { className: 'dash-actions' }, h(Button, { showArrow: false, onClick: p.onCreate }, 'Create a batch'))),
      p.loading ? h(Loading, { text: 'Loading batches\u2026' }) : b.length === 0 ?
        h(Empty, { icon: 'batch', title: 'No batches yet', text: 'Create your first batch to follow a harvest from farm to buyer.', action: h('div', { className: 'empty-actions' }, h(Button, { showArrow: false, onClick: p.onCreate }, 'Create a batch'), h(Button, { variant: 'secondary', showArrow: false, onClick: p.onSeed }, 'Add sample batches')) }) :
      h(React.Fragment, null,
        h('div', { className: 'kpis' }, metrics.map(function (m, i) {
          return h('button', { key: m[0], className: 'kpi' + (i === 1 && risky.length ? ' kpi-alert' : ''), onClick: function () { p.go(m[4]); } }, h('span', { className: 'kpi-ic' }, h(Ic, { n: m[3], size: 17 })), h('small', null, m[0]), h('strong', null, m[1]), h('em', null, m[2]));
        })),
        h('div', { className: 'attn-zone' },
          h('div', { className: 'attn-head' }, h('div', null, h('span', { className: 'attn-label' }, h('i', null), risky.length ? 'ATTENTION REQUIRED' : 'ALL CLEAR'), h('h3', null, risky.length ? risky.length + ' batch' + (risky.length > 1 ? 'es need' : ' needs') + ' action' : 'No active risks')), risky.length > 0 && h('button', { className: 'dx-link', onClick: function () { p.go('risk'); } }, 'Open Risk Monitor \u2192')),
          risky.length === 0 ? h(Empty, { icon: 'shield', title: 'No active risks', text: 'Every tracked batch is within the recommended temperature, delay and humidity range.' }) :
          h('div', { className: 'alert-stack' }, risky.slice(0, 2).map(function (x) { return h(AlertCard, { key: x.id, batch: x, go: p.go, onAction: p.onAction, acting: p.acting }); }))),
        h('div', { className: 'dash-active' },
          h('div', { className: 'sec-title' }, h('div', null, h('span', { className: 'micro' }, 'ACTIVE JOURNEYS'), h('h3', null, active.length + ' batches in motion')), h('button', { className: 'dx-link', onClick: function () { p.go('batches'); } }, 'View all')),
          h('div', { className: 'ab-list' }, active.slice(0, 5).map(function (x) {
            var a = assess(x);
            return h('button', { key: x.id, className: 'ab', onClick: function () { p.go('journey/' + x.id); } },
              h('span', { className: 'ab-id' }, h(Thumb, { b: x }), h('span', null, h('strong', null, x.id), h('small', null, x.crop + ' \u00B7 ' + x.quantity))),
              h('span', { className: 'ab-route' }, h('small', null, h(Ic, { n: 'pin', size: 12 }), x.origin + ' \u2192 ' + x.destination), h(MiniJourney, { b: x })),
              h('span', { className: 'ab-cond' }, h('span', { className: 'chip chip-' + a.tState }, h(Ic, { n: 'therm', size: 12 }), a.t.toFixed(1) + '\u00B0'), h('small', null, x.stage)),
              h(RiskPill, { b: x }));
          }))),
        h('div', { className: 'dash-recent' },
          h('div', { className: 'sec-title' }, h('div', null, h('span', { className: 'micro' }, 'RECENT ACTIVITY'), h('h3', null, 'What changed')), h('button', { className: 'dx-link', onClick: function () { p.go('traceability/' + p.selectedId); } }, 'Full history')),
          (p.events || []).length === 0 ? h(Empty, { icon: 'clock', title: 'No journey events', text: 'Events appear here as batches are loaded, moved and stored.' }) :
          h('ul', { className: 'feed2' }, p.events.slice(0, 6).map(function (e) {
            return h('li', { key: e.id, className: 'f-' + (e.tone || 'low') }, h('span', { className: 'f-ic' }, h(Ic, { n: STAGE_ICON[stageIdx(e.stage)], size: 14 })), h('button', { onClick: function () { p.go('journey/' + e.batchId); } }, h('strong', null, e.batchId + ' \u00B7 ' + (/delay/i.test(e.stage) ? 'Delay detected' : e.stage)), h('small', null, h(Ic, { n: 'pin', size: 11 }), (e.location || '') + ' \u00B7 ' + evtWhen(e))));
          })))));
  }

  /* ---------- JOURNEY RAIL (shared by detail) ---------- */
  function Rail(p) {
    var cur = stageIdx(p.batch.stage), evs = p.events || [];
    return h('div', { className: 'rail rail-' + tone(p.batch) }, STAGES.map(function (s, i) {
      var ev = evs.filter(function (e) { return stageIdx(e.stage) === i; }).slice(-1)[0], st = i < cur ? 'done' : i === cur ? 'now' : '';
      return h('div', { key: s, className: 'rail-s ' + st }, h('span', { className: 'rail-n' }, h(Ic, { n: STAGE_ICON[i], size: 16 })), h('strong', null, s), h('small', null, ev ? evtWhen(ev) : (st ? '' : 'Pending')));
    }));
  }

  /* ---------- BATCH DETAIL ---------- */
  function BatchDetail(p) {
    var ui = UI(), Button = ui.Button, b = p.batch, a = assess(b), cl = V.climateFor(b), evs = (p.events || []).slice().reverse();
    return h('section', { className: 'workspace-section bd', id: 'live-journey', 'data-dashboard-section': true },
      h('div', { className: 'bd-hero bd-' + tone(b) },
        h('div', { className: 'ph bd-photo', style: { backgroundImage: 'url(' + (b.image || '') + '), linear-gradient(135deg,#1d4a35,#2a1f16)' }, role: 'img', 'aria-label': b.crop }),
        h('div', { className: 'bd-id' },
          h('span', { className: 'bd-state' }, h('i', null), b.stage),
          h('h1', null, b.id), h('p', { className: 'bd-sub' }, b.crop + ' \u00B7 ' + (b.grade || 'Grade A') + ' \u00B7 ' + b.quantity),
          h('div', { className: 'bd-route' }, h(Ic, { n: 'pin', size: 15 }), h('strong', null, b.origin), h(Ic, { n: 'arrow', size: 14 }), h(Ic, { n: 'pin', size: 15 }), h('strong', null, b.destination)),
          h('small', { className: 'bd-upd' }, 'Harvested ' + (b.harvestDate ? fmtDate(b.harvestDate) : '\u2014') + ' \u00B7 Last updated ' + b.updated)),
        h('div', { className: 'bd-actions' }, h(Button, { showArrow: false, onClick: p.onVerify }, 'Buyer verification'), h(Button, { variant: 'secondary', showArrow: false, onClick: p.onAddEvent }, 'Log event'))),
      h('div', { className: 'tiles' },
        h('div', { className: 'tile t-' + a.tState }, h('span', { className: 'tile-k' }, h(Ic, { n: 'therm', size: 14 }), 'Temperature'), h('strong', null, a.t.toFixed(1) + '\u00B0C'), h(Spark, { batch: b, state: a.tState }), h('small', null, 'Limit 30\u00B0C')),
        h('div', { className: 'tile t-' + a.hState }, h('span', { className: 'tile-k' }, h(Ic, { n: 'drop', size: 14 }), 'Humidity'), h('strong', null, a.hum + '%'), h(Meter, { v: a.hum, min: 30, max: 100, limit: 70, state: a.hState }), h('small', null, 'Limit 70%')),
        h('div', { className: 'tile t-' + a.dState }, h('span', { className: 'tile-k' }, h(Ic, { n: 'clock', size: 14 }), 'Delay'), h('strong', null, a.d >= 1 ? '+' + a.d + ' hr' : 'On time'), h(Meter, { v: a.d, min: 0, max: 6, limit: 1, state: a.dState }), h('small', null, a.d >= 1 ? 'Behind schedule' : 'On schedule')),
        h('div', { className: 'tile t-ok' }, h('span', { className: 'tile-k' }, h(Ic, { n: weatherIcon(cl.weather), size: 14 }), 'Weather'), h('strong', { className: 'tile-sm' }, cl.weather), h('div', { className: 'rainbar' }, h('i', { style: { width: cl.rainProb + '%' } })), h('small', null, cl.rainProb + '% chance of rain')),
        h('div', { className: 'tile tile-risk t-' + a.tState + ' tr-' + tone(b) }, h('span', { className: 'tile-k' }, h(Ic, { n: 'shield', size: 14 }), 'Risk'), h('strong', { className: 'tile-sm' }, b.risk), h(Severity, { risk: b.risk }), h('small', null, 'Rule score ' + (b.riskScore || 0)))),
      h('div', { className: 'bd-block' }, h('div', { className: 'sec-title' }, h('div', null, h('span', { className: 'micro' }, 'JOURNEY'), h('h3', null, (b.progress || 0) + '% complete'))), h(Rail, { batch: b, events: p.events })),
      h('div', { className: 'bd-block rw rw-' + tone(b) }, h('div', { className: 'sec-title' }, h('div', null, h('span', { className: 'micro' }, 'RISK ASSESSMENT'), h('h3', null, b.risk + ' risk'))),
        h('div', { className: 'rw-cols' },
          h('div', null, h('span', { className: 'micro' }, 'WHY'), h('p', null, a.why.join(' '))),
          h('div', null, h('span', { className: 'micro' }, 'RECOMMENDED ACTION'), h('p', { className: 'alert-act' }, a.action),
            b.actionTaken ? h('span', { className: 'alert-done' }, h(Ic, { n: 'check', size: 14 }), ' Action recorded') : b.risk !== 'Low' && h(Button, { showArrow: false, disabled: p.acting, onClick: p.onMarkAction }, p.acting ? 'Saving\u2026' : 'Take action')))),
      h('div', { className: 'bd-block' }, h('div', { className: 'sec-title' }, h('div', null, h('span', { className: 'micro' }, 'EVENT HISTORY'), h('h3', null, evs.length + ' event' + (evs.length === 1 ? '' : 's'))), h('button', { className: 'dx-link', onClick: function () { p.go('traceability/' + b.id); } }, 'Full timeline \u2192')),
        evs.length === 0 ? h(Empty, { icon: 'clock', title: 'No journey events', text: 'Log the first event to start this batch\u2019s history.', action: h(Button, { showArrow: false, onClick: p.onAddEvent }, 'Log event') }) :
        h('ul', { className: 'feed2' }, evs.slice(0, 6).map(function (e) { return h('li', { key: e.id, className: 'f-' + (e.tone || 'low') }, h('span', { className: 'f-ic' }, h(Ic, { n: STAGE_ICON[stageIdx(e.stage)], size: 14 })), h('div', null, h('strong', null, /delay/i.test(e.stage) ? 'Delay detected' : e.stage), h('small', null, h(Ic, { n: 'pin', size: 11 }), (e.location || '') + ' \u00B7 ' + evtWhen(e) + (e.temperature ? ' \u00B7 ' + e.temperature : '')))); }))));
  }

  /* ---------- RISK MONITOR ---------- */
  function RiskMonitor(p) {
    var b = p.batches.slice(), order = { High: 0, Watch: 1, Low: 2 };
    b.sort(function (x, y) { return order[x.risk] - order[y.risk] || (y.riskScore || 0) - (x.riskScore || 0); });
    var risky = b.filter(function (x) { return x.risk !== 'Low'; }), low = b.filter(function (x) { return x.risk === 'Low'; });
    var cnt = { High: 0, Watch: 0, Low: 0 }; b.forEach(function (x) { cnt[x.risk] = (cnt[x.risk] || 0) + 1; });
    return h('section', { className: 'workspace-section rm', id: 'risk-monitor', 'data-dashboard-section': true },
      h(Head, { label: 'RISK MONITOR', title: 'Know what needs attention', copy: 'Each batch is checked against temperature (30\u00B0C), delay (1 hr) and humidity (70%) limits.' }),
      p.loading ? h(Loading, { text: 'Loading risk data\u2026' }) : b.length === 0 ? h(Empty, { icon: 'risk', title: 'No batches to monitor', text: 'Risk is assessed for every batch you create.' }) :
      h(React.Fragment, null,
        h('div', { className: 'rm-sum' }, ['High', 'Watch', 'Low'].map(function (l) { return h('div', { key: l, className: 'rm-s rm-' + l.toLowerCase() }, h('i', null), h('strong', null, cnt[l]), h('small', null, l + ' risk')); })),
        risky.length === 0 ? h(Empty, { icon: 'shield', title: 'No active risks', text: 'All batches are within the recommended range.' }) : h('div', { className: 'alert-stack' }, risky.map(function (x) { return h(AlertCard, { key: x.id, batch: x, go: p.go, onAction: p.onAction, acting: p.acting }); })),
        low.length > 0 && h('div', { className: 'rm-low' }, h('span', { className: 'micro' }, 'WITHIN RANGE'), low.map(function (x) { var a = assess(x); return h('button', { key: x.id, className: 'rm-lrow', onClick: function () { p.go('journey/' + x.id); } }, h(Thumb, { b: x }), h('strong', null, x.id), h('small', null, x.crop + ' \u00B7 ' + x.stage), h('span', { className: 'chip chip-ok' }, a.t.toFixed(1) + '\u00B0C \u00B7 ' + a.hum + '% RH'), h(RiskPill, { b: x })); }))));
  }

  /* ---------- TRACEABILITY ---------- */
  function Timeline(p) {
    var ui = UI(), b = p.batch, cur = stageIdx(b.stage), evs = p.events || [];
    var rows = STAGES.map(function (s, i) { return { name: s, i: i, ev: evs.filter(function (e) { return stageIdx(e.stage) === i; }) }; });
    return h('section', { className: 'workspace-section tl', id: 'traceability', 'data-dashboard-section': true },
      h(Head, { label: 'TRACEABILITY', title: 'Batch ' + (b.batchNumber || b.id) + ' timeline', copy: b.crop + ' \u00B7 ' + b.origin + ' \u2192 ' + b.destination, action: h(ui.Button, { showArrow: false, onClick: p.onAddEvent }, '+ Log event') }),
      evs.length === 0 ? h(Empty, { icon: 'clock', title: 'No journey events', text: 'This batch has no recorded events yet.', action: h(ui.Button, { showArrow: false, onClick: p.onAddEvent }, 'Log first event') }) :
      h('ol', { className: 'vt' }, rows.map(function (r) {
        var state = r.ev.length ? (r.i === cur ? 'now' : 'done') : (r.i < cur ? 'skipped' : 'pending');
        return h('li', { key: r.name, className: 'vt-i ' + state },
          h('span', { className: 'vt-node' }, h(Ic, { n: STAGE_ICON[r.i], size: 18 })),
          h('div', { className: 'vt-body' }, h('h3', null, r.name, state === 'now' && h('em', null, 'Current')),
            r.ev.length === 0 ? h('p', { className: 'vt-none' }, state === 'pending' ? 'Pending' : 'No event recorded') :
            r.ev.map(function (e) {
              var delay = /delay/i.test(e.stage);
              return h('div', { key: e.id, className: 'vt-ev vt-' + (e.tone || 'low') },
                h('div', { className: 'vt-when' }, h(Ic, { n: 'clock', size: 12 }), evtWhen(e)),
                h('strong', null, delay ? 'Delay detected' : e.stage), h('p', null, h(Ic, { n: 'pin', size: 12 }), e.location),
                h('div', { className: 'vt-chips' }, e.temperature && h('span', null, h(Ic, { n: 'therm', size: 11 }), e.temperature), e.humidity && h('span', null, h(Ic, { n: 'drop', size: 11 }), e.humidity), e.risk && h('span', { className: 'vt-r' }, e.risk)),
                e.notes && h('small', null, e.notes));
            }),
            state === 'now' && h('div', { className: 'vt-now' }, h('i', null), 'Currently ' + b.stage.toLowerCase() + ' \u00B7 Last updated ' + b.updated)));
      })));
  }

  /* ---------- CLIMATE ---------- */
  function Climate(p) {
    var b = p.batch, cl = V.climateFor(b), a = assess(b), rain = cl.rainProb;
    var rows = [
      ['Temperature', 'therm', a.tState === 'ok' ? 'Normal' : a.tState === 'warn' ? 'Watch' : 'High', a.tState, a.t.toFixed(1) + '\u00B0C against a 30\u00B0C limit'],
      ['Humidity', 'drop', a.hState === 'ok' ? 'Normal' : a.hState === 'warn' ? 'Watch' : 'High', a.hState, a.hum + '% RH against a 70% limit'],
      ['Rain', 'rain', rain >= 50 ? 'High impact' : rain >= 25 ? 'Watch' : 'Low impact', rain >= 50 ? 'bad' : rain >= 25 ? 'warn' : 'ok', rain + '% chance on the route']];
    var score = rows.reduce(function (s, r) { return Math.max(s, { ok: 0, warn: 1, bad: 2 }[r[3]]); }, 0), overall = ['Low', 'Watch', 'High'][score];
    var fx = { therm: a.tState === 'ok' ? 'Within the safe range for ' + b.crop.toLowerCase() + '.' : 'Heat speeds ripening and softening, shortening shelf life.', drop: a.hState === 'ok' ? 'Acceptable for this crop.' : 'Can encourage mould and decay if ventilation is poor.', rain: rain >= 50 ? 'May delay trucks and wet crates.' : 'Unlikely to delay this journey.' };
    return h('section', { className: 'workspace-section cl', id: 'climate-context', 'data-dashboard-section': true },
      h(Head, { label: 'CLIMATE', title: 'Climate for batch ' + (b.batchNumber || b.id), copy: 'Environmental conditions along ' + b.origin + ' \u2192 ' + b.destination + ' and how they affect this batch.' }),
      h('div', { className: 'cl-flow' },
        h('div', { className: 'cl-now' }, h('span', { className: 'micro' }, 'CURRENT CONDITIONS'), h('div', { className: 'cl-big' }, h(Ic, { n: weatherIcon(cl.weather), size: 44, className: 'cl-wi' }), h('strong', null, a.t.toFixed(0) + '\u00B0')), h('span', null, cl.weather), h('small', null, h(Ic, { n: 'pin', size: 12 }), cl.location),
          h('div', { className: 'cl-bars' }, h('div', null, h('small', null, 'Humidity'), h(Meter, { v: a.hum, min: 30, max: 100, limit: 70, state: a.hState }), h('b', null, a.hum + '%')), h('div', null, h('small', null, 'Rain'), h('div', { className: 'rainbar' }, h('i', { style: { width: rain + '%' } })), h('b', null, rain + '%')))),
        h('i', { className: 'cl-arr' }, h(Ic, { n: 'arrow', size: 18 })),
        h('div', { className: 'cl-batch' }, h(Thumb, { b: b }), h('strong', null, b.id), h('small', null, b.crop + ' \u00B7 ' + b.stage), h(MiniJourney, { b: b })),
        h('i', { className: 'cl-arr' }, h(Ic, { n: 'arrow', size: 18 })),
        h('div', { className: 'cl-over cl-o-' + overall.toLowerCase() }, h('span', { className: 'micro' }, 'OVERALL EXPOSURE'), h('strong', null, overall.toUpperCase()), h(Severity, { risk: overall }))),
      h('div', { className: 'sec-title' }, h('div', null, h('span', { className: 'micro' }, 'CLIMATE IMPACT'), h('h3', null, 'Effect on this batch'))),
      h('div', { className: 'cl-rows' }, rows.map(function (r) { return h('div', { key: r[0], className: 'cl-r c-' + r[3] }, h('span', { className: 'cl-ric' }, h(Ic, { n: r[1], size: 18 })), h('div', null, h('strong', null, r[0]), h('small', null, r[4])), h('em', null, r[2]), h('p', null, fx[r[1]])); })));
  }

  /* ---------- QR VERIFICATION ---------- */
  var QR = Array.from({ length: 169 }, function (_, i) { var x = i % 13, y = Math.floor(i / 13); var f = (x < 4 && y < 4) || (x > 8 && y < 4) || (x < 4 && y > 8); if (f) { var lx = x % 9 > 3 ? x - 9 : x, ly = y > 8 ? y - 9 : y; return lx === 0 || ly === 0 || lx === 3 || ly === 3 || (lx > 0 && lx < 3 && ly > 0 && ly < 3 && lx === 1 && ly === 1) || (lx === 2 && ly === 2) || (lx === 1 && ly === 2) || (lx === 2 && ly === 1); } return ((x * 5 + y * 7 + x * y) % 3 === 0); });
  function Verify(p) {
    var ui = UI(), b = p.batch, a = assess(b), evs = p.events || [], cond = b.risk === 'High' ? 'Needs attention' : b.risk === 'Watch' ? 'Under watch' : 'Good condition';
    var q = function (n, k, body) { return h('div', { className: 'vq' }, h('span', { className: 'vq-n' }, n), h('div', null, h('small', null, k), body)); };
    return h('section', { className: p.modal ? 'vf vf-modal' : 'workspace-section vf', id: 'buyers', 'data-dashboard-section': true },
      !p.modal && h(Head, { label: 'BATCH VERIFICATION', title: 'Scan. Verify. Trust.', copy: 'Every batch carries one QR code. Scanning it opens this verified record.' }),
      h('div', { className: 'vf-card' },
        h('div', { className: 'vf-qr' }, h('div', { className: 'vf-code', 'aria-label': 'QR code for batch ' + b.id }, QR.map(function (on, i) { return h('i', { key: i, className: on ? 'on' : '' }); })), h('strong', null, b.batchNumber || b.id), h('span', { className: 'vf-scan' }, h(Ic, { n: 'scan', size: 14 }), 'Scan to verify')),
        h('div', { className: 'vf-info' },
          h('div', { className: 'vf-top' }, h('div', null, h('span', { className: 'micro' }, 'VERIFIED BATCH RECORD'), h('h3', null, b.crop + ' \u00B7 ' + (b.variety || b.grade || ''))), h(RiskPill, { b: b })),
          h('div', { className: 'vf-q' },
            q('1', 'Where did it come from?', h('strong', null, b.origin)), q('2', 'Harvested', h('strong', null, b.harvestDate ? fmtDate(b.harvestDate) : '\u2014')),
            q('3', 'Current stage', h('strong', null, b.stage + ' \u2192 ' + b.destination)), q('4', 'Current condition', h('strong', null, cond + ' \u00B7 ' + a.t.toFixed(1) + '\u00B0C \u00B7 ' + a.hum + '% RH'))),
          h('div', { className: 'vf-risk vf-r-' + tone(b) }, h(Ic, { n: b.risk === 'Low' ? 'shield' : 'warn', size: 16 }), h('div', null, h('strong', null, b.risk === 'Low' ? 'No risk flagged' : b.risk + ' risk flagged'), h('small', null, a.why[0]))))),
      h('div', { className: 'vf-hist' }, h('span', { className: 'micro' }, 'WHAT HAPPENED DURING THE JOURNEY'),
        evs.length === 0 ? h(Empty, { icon: 'clock', title: 'No journey events', text: 'No history has been recorded for this batch.' }) :
        h('ul', { className: 'feed2' }, evs.map(function (e) { return h('li', { key: e.id, className: 'f-' + (e.tone || 'low') }, h('span', { className: 'f-ic' }, h(Ic, { n: STAGE_ICON[stageIdx(e.stage)], size: 14 })), h('div', null, h('strong', null, /delay/i.test(e.stage) ? 'Delay detected' : e.stage), h('small', null, h(Ic, { n: 'pin', size: 11 }), (e.location || '') + ' \u00B7 ' + evtWhen(e)))); }))));
  }

  /* ---------- BUYERS ---------- */
  function Buyers(p) {
    var ui = UI(), buyers = V.buyersWithStats(p.batches), st = useState(null), open = st[0], setOpen = st[1];
    return h('section', { className: 'workspace-section bu', id: 'buyers', 'data-dashboard-section': true },
      h(Head, { label: 'BUYERS', title: 'Buyers and incoming produce', copy: 'Who is receiving what, and the verified record behind every batch.' }),
      p.batches.length === 0 ? h(Empty, { icon: 'user', title: 'No buyers yet', text: 'Buyers appear once batches are created with a destination.' }) :
      h('div', { className: 'bu-list' }, buyers.map(function (x) {
        var incoming = x.batches.filter(function (b) { return b.stage !== 'Delivered'; }), kg = incoming.reduce(function (a, b) { return a + (b.quantityKg || num(b.quantity)); }, 0), isOpen = open === x.id || (open == null && x === buyers[0]);
        return h('div', { key: x.id, className: 'bu' + (isOpen ? ' open' : '') },
          h('button', { className: 'bu-head', onClick: function () { setOpen(isOpen ? '' : x.id); }, 'aria-expanded': isOpen },
            h('span', { className: 'bu-av' }, x.name.split(' ').slice(0, 2).map(function (w) { return w[0]; }).join('')),
            h('span', { className: 'bu-name' }, h('strong', null, x.name), h('small', null, h(Ic, { n: 'pin', size: 11 }), x.location + ' \u00B7 ' + x.type)),
            h('span', { className: 'bu-stat' }, h('b', null, incoming.length), h('small', null, 'Active batches')), h('span', { className: 'bu-stat' }, h('b', null, kg + ' kg'), h('small', null, 'Incoming')), h('span', { className: 'bu-stat bu-hide' }, h('b', null, x.lastDelivery || '\u2014'), h('small', null, 'Last delivery')),
            h('span', { className: 'rpill rpill-' + x.statusTone }, h('i', null), x.status)),
          isOpen && h('div', { className: 'bu-body' }, x.batches.length === 0 ? h('p', { className: 'vt-none' }, 'No batches linked to this buyer yet.') : x.batches.map(function (b) {
            return h('div', { key: b.id, className: 'bu-b' }, h(Thumb, { b: b }), h('div', null, h('strong', null, b.id + ' \u00B7 ' + b.crop), h('small', null, b.stage + ' \u00B7 from ' + b.origin)), h(MiniJourney, { b: b }), h(RiskPill, { b: b }), h('button', { className: 'dx-link', onClick: function () { p.go('verify/' + b.id); } }, h(Ic, { n: 'scan', size: 13 }), ' Verify'));
          })));
      })));
  }

  window.CropTraceScreens = { Dashboard: Dashboard, BatchDetail: BatchDetail, RiskMonitor: RiskMonitor, Timeline: Timeline, Climate: Climate, Verify: Verify, Buyers: Buyers, Empty: Empty, Loading: Loading };
})();
